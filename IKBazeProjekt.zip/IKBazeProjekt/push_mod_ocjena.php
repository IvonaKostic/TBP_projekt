<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $baza = new Baza();
    $baza->spojiDB();
    if (isset($_GET["kid"]) && isset($_GET["rid"]) && isset($_GET["ocjena"]) && isset($_GET["komentar"])) {
        $upit = "UPDATE SLIJEDI_RECEPT SET ocjena = {$_GET["ocjena"]}, komentar = '{$_GET["komentar"]}' WHERE korisnik_id = {$_GET["kid"]} AND recept_id = {$_GET["rid"]}";
        echo $upit; // Debug statement
        $baza->updateDB($upit);

    }
    echo json_encode("gotovo");

    $baza->zatvoriDB();
}