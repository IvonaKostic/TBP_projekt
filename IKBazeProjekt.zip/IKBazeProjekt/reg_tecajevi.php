<?php
require 'zaglavlje.php';

if(isset($_SESSION["uloga"]) && $_SESSION["uloga"]>=2){
    $smarty->display("reg_tecajevi.tpl");
}
require 'podnozje.php';