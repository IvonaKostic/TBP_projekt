<?php

class Registracija {

    function registriraj($korime, $email, $lozinka, $ime, $prezime, $baza) {
        $datum = date('Y-m-d H:i:s');
        $datum = date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $datum)));
        $sol = $this->generirajRandomString(20);
        $lozinka_hash = hash('sha1', $sol . $lozinka);
        $upit = 'INSERT INTO KORISNICI("ime", "prezime", "korime", "email", "lozinka","sol", "lozinka_sha1", "datum_registracije", "ULOGE_id_uloga")'
                . "VALUES ('{$ime}','{$prezime}','{$korime}','{$email}','{$lozinka}','{$sol}','{$lozinka_hash}','{$datum}',2)";
        $rezultat = $baza->updateDB($upit);
        //$rezultat_assoc = mysqli_fetch_assoc($rezultat);
        // Send email validation
        if ($rezultat) {
            $this->posaljiEmail($korime, $email, $baza);
        }

        return $rezultat;
    }

    function posaljiEmail($korisnik, $email, $baza) {
        $kod = $this->generirajRandomString(40);
        $upit = "UPDATE KORISNICI SET aktivacijski_kod = '{$kod}' WHERE korime = '{$korisnik}' AND  email = '{$email}'";
        $baza->updateDB($upit);

        $link = "http://" . $_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']) . "/aktivacija.php?kod=" . $kod;
        $toEmail = '{$email}';
        $subject = "Aktivacija novog računa";
        $content = "Otvorite link za aktivaciju: " . $link;
        $mailHeaders = "From: Admin\r\n";
        $mailHeaders .= "Reply-To: Admin\r\n";

        if (mail($toEmail, $subject, $content, $mailHeaders)) {
            echo 'Email sent successfully.';
            return true;
        }
        echo 'Error sending email.';
        return false;
    }

    function aktiviraj($kod, $baza) {
        $upit = "UPDATE KORISNICI SET omogucen = 1 WHERE aktivacijski_kod = '{$kod}'";
        $result = $baza->updateDB($upit);
        $upit = "SELECT * FROM KORISNICI WHERE aktivacijski_kod = '{$kod}'";
        $result = $baza->selectDB($upit);
        ob_start();
        fb($upit);
        $result_array = pg_fetch_assoc($result);
        fb($result_array["omogucen"]);
        if ($result_array["omogucen"] == 1 || $result_array["omogucen"] === "1")
            return true;
        return false;
    }

    function generirajRandomString($n) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';

        for ($i = 0; $i < $n; $i++) {
            $index = rand(0, strlen($characters) - 1);
            $randomString .= $characters[$index];
        }

        return $randomString;
    }

}
