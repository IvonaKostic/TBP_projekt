<?php
require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    if (isset($_POST["ocjena"]) && isset($_POST["komentar"]) && isset($_POST["id_tecaj"])) {
        $ocjena = $_POST["ocjena"];
        $komentar = $_POST["komentar"];
        $idTecaj = $_POST["id_tecaj"];

        // Update the ocjena and komentar values in the database
        $veza = new Baza();
        $veza->spojiDB();

        $updateQuery = "UPDATE TECAJEVI SET ocjena = '{$ocjena}', komentar = '{$komentar}' WHERE id_tecaj = '{$idTecaj}'";
        $veza->updateDB($updateQuery);

        $veza->zatvoriDB();

        // Return a response indicating the update was successful
        echo json_encode("Values updated successfully");
    } else {
        // Return a response indicating missing parameters
        echo json_encode("Missing parameters");
    }
}
?>
