<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    if (isset($_GET["id"])) {
        $id_kat = $_GET["id"];
        $smarty->assign("spremnik", $id_kat);

        $smarty->display("mod_kat_recepti.tpl");
    }
}
require 'podnozje.php';
