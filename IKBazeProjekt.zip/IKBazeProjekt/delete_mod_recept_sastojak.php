<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    //$podaci = array();

    $baza = new Baza();
    $baza->spojiDB();
    $id_sastojak = $_GET["id"];
    $id_recept = $_GET["idrec"];

    $upit = "DELETE FROM \"SADRZI_SASTOJAK\" WHERE \"SASTOJCI_id_sastojak\"= {$id_sastojak} AND \"RECEPTI_id_recept\" = {$id_recept}";
    $baza->updateDB($upit);

    echo json_encode("gotovo");
    $baza->zatvoriDB();
}