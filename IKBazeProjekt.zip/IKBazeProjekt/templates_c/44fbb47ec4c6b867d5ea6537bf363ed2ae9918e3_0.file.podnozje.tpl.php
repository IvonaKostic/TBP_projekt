<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:02:39
  from 'C:\xampp\htdocs\moj-server\templates\podnozje.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6494547fd92895_86056358',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '44fbb47ec4c6b867d5ea6537bf363ed2ae9918e3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\podnozje.tpl',
      1 => 1675517836,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6494547fd92895_86056358 (Smarty_Internal_Template $_smarty_tpl) {
?>  <footer>

            <address>Kontakt: <a href="mailto:ikostic@foi.hr">Ivona Koštić</a></address>
            <p>&copy; 2023. I.Koštić</p>
           
        </footer>
    </body>
</html>
<?php }
}
