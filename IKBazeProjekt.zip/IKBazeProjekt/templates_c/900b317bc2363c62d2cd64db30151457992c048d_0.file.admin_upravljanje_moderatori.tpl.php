<?php
/* Smarty version 4.3.1, created on 2023-07-10 12:27:44
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\admin_upravljanje_moderatori.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64abdd20ba6339_96035193',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '900b317bc2363c62d2cd64db30151457992c048d' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\admin_upravljanje_moderatori.tpl',
      1 => 1688830261,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64abdd20ba6339_96035193 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/admin_upravljanje_moderatori.js"><?php echo '</script'; ?>
>

<title>Moderatori</title>

<div id="tablicaDiv">
    <table id="tablica">
        <thead>
            <tr>
                <th><a style="cursor: pointer;">Ime Prezime</a></th>
                <th><a style="cursor: pointer;">Korime</a></th>
                <th><a style="cursor: pointer;">ID</a></th>
                <th><a style="cursor: pointer;">Uloga</a></th>
                <th><a style="cursor: pointer;">Datum registracije</a></th>
                <th><a style="cursor: pointer;">Omogućen</a></th>
                <th>Akcija</th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>


<?php }
}
