<?php
/* Smarty version 4.3.1, created on 2023-07-03 16:04:47
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_azuriraj_tecaj.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64a2d57f301a91_56273954',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6967d41318227dbf64c496a8ad9297b4b7eb7223' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_azuriraj_tecaj.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2d57f301a91_56273954 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_dodaj_tecaj.js"><?php echo '</script'; ?>
>
<title>Novi tečaj</title>



<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['naziv']->value;?>
" name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['opis']->value;?>
" name="Opis">    
    <br><br> 

    <label><b>Broj mjesta<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['brojmjesta']->value;?>
" name="BrojMjesta">    
    <br><br> 

    <label for="start">Rok prijave i početak:</label>

    <input type="date" value="<?php echo $_smarty_tpl->tpl_vars['rok_prijave']->value;?>
" id="start" name="RokPrijave">

    <br><br>     
    <label for="stop">Datum završetka:</label>

    <input type="date" value="<?php echo $_smarty_tpl->tpl_vars['datum_zavrsetka']->value;?>
" id="stop" name="Kraj">

    <br><br> 
    <label for="dropdown">Recept:</label>
    <select name="recept" value="<?php echo $_smarty_tpl->tpl_vars['recept']->value;?>
" id="dropdown">
    </select>

    <br><br> 
    <input type="submit" name="submitDodaj" class="NiceButton" id="buttonDodaj" value="Spremi">       






</form>

<br><br><br>

<?php }
}
