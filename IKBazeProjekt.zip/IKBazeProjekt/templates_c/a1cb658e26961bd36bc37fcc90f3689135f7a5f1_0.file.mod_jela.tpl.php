<?php
/* Smarty version 4.3.1, created on 2023-07-13 22:21:45
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_jela.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64b05cd94d15b5_50557782',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a1cb658e26961bd36bc37fcc90f3689135f7a5f1' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_jela.tpl',
      1 => 1689279699,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64b05cd94d15b5_50557782 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_jela.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"><?php echo '</script'; ?>
>


<title>Jela</title>


<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Korisnik</a></th>

                <th><a style="cursor: pointer;">Recept</a></th>
                <th><a style="cursor: pointer;">Ocjena</a></th>
                <th><a style="cursor: pointer;">Komentar</a></th>
                <th><a style="cursor: pointer;">Slika</a></th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php }
}
