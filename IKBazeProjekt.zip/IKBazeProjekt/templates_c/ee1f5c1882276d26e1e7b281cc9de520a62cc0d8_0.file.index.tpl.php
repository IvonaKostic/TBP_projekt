<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:26:23
  from 'C:\xampp\htdocs\moj-server\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64945a0f81acc7_78296135',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee1f5c1882276d26e1e7b281cc9de520a62cc0d8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\index.tpl',
      1 => 1686989894,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64945a0f81acc7_78296135 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <div class="treciBlok">

                <div class="treciBlokUnutra">
                    <div class="treciBlokIntro">
                        <h1>O autoru</h1>
                        <img class="slikaAutorice" src="materijali/kosta.png">
                    </div>
                    <div class="treciBlokLista1">
                        <ul>
                            <li>Ime: Ivona</li>
                            <li>Prezime: Koštić</li>
                            <li>E-mail: ikostic@foi.hr</li>
                            <li>Životopis: <br>
                                Ivona Koštić, studentica na fakultetu Organizacije i informatike u Varaždinu <br>
                                Rođena u Vinkovcima<br>
                                22 godine
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
<?php }
}
