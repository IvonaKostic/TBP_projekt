<?php
/* Smarty version 4.3.1, created on 2023-07-03 20:38:27
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64a315a3c59753_19437911',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f9b648578756a227521ee60c0ce87e5f673bf2dc' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\index.tpl',
      1 => 1688409448,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a315a3c59753_19437911 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="treciBlok">

    <div class="treciBlokUnutra">
        <div class="treciBlokIntro">
            <h1>O autoru</h1>
        </div>
        <div class="treciBlokLista1">
            <ul>
                <li>Ime: Ivona</li>
                <li>Prezime: Koštić</li>
                <li>E-mail: ikostic@foi.hr</li>
                <li>Životopis: <br>
                    Ivona Koštić, studentica na fakultetu Organizacije i informatike u Varaždinu <br>
                    Rođena u Vinkovcima<br>
                    22 godine
                </li>
            </ul>

        </div>
    </div>
</div>
<?php }
}
