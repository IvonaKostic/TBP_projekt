<?php
/* Smarty version 4.3.1, created on 2023-06-22 17:41:34
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\podnozje.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64946bae13d7c0_17707566',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '00e35f3199307905059cd552c52dff058137a40d' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\podnozje.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64946bae13d7c0_17707566 (Smarty_Internal_Template $_smarty_tpl) {
?>  <footer>

            <address>Kontakt: <a href="mailto:ikostic@foi.hr">Ivona Koštić</a></address>
            <p>&copy; 2023. I.Koštić</p>
           
        </footer>
    </body>
</html>
<?php }
}
