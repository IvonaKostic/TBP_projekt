<?php
/* Smarty version 4.3.1, created on 2023-06-22 17:43:28
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\reg_tecaj_recepti.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64946c20501999_22209109',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6e4c7e8222620de0e9ae62e13150926ea28c5868' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\reg_tecaj_recepti.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64946c20501999_22209109 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/reg_tecaj_recepti.js"><?php echo '</script'; ?>
>


<title>Recept</title>


<div id="tablicaDiv">

    <br><br>
    <label><b>Naziv jela<br>   
        </b>    
    </label>    
    <input type="text" id="naziv" disabled name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="textarea" rows="4" cols="50" id="opis" disabled name="Naziv">    
    <br><br> 

    <label><b>Postupak<br>   
        </b>    
    </label>    
    <input type="textarea" rows="4" cols="50" id="postupak" disabled name="Naziv">    
    <br><br> 

    <label><b>Broj osoba<br>   
        </b>    
    </label>    
    <input type="text" id="brosoba" disabled name="Naziv">    
    <br><br> 
    <label><b>Sastojci<br>   
        </b>    
    </label> 
    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>
                <th><a style="cursor: pointer;">Količina</a></th>

            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
    <div id="formaDodavanje">

    </div>
    <label><b>Video uputa<br>   
        </b>    
    </label> 
    <br><br> 
    <iframe class="cijeli" id="video" onload="resizeIframe(this) src =""></iframe> 
    <br><br> 


    <br><br> 
    <br><br> 
    <br><br> 
    <div id="spremnik" style="visibility: hidden">
        <?php echo $_smarty_tpl->tpl_vars['spremnik']->value;?>

    </div>
</div>

<?php }
}
