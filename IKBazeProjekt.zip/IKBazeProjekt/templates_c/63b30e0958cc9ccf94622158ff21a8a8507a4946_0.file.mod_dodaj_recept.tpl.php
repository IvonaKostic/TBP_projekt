<?php
/* Smarty version 4.3.1, created on 2023-07-03 16:09:42
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_dodaj_recept.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64a2d6a6b52de2_32223440',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '63b30e0958cc9ccf94622158ff21a8a8507a4946' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_dodaj_recept.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2d6a6b52de2_32223440 (Smarty_Internal_Template $_smarty_tpl) {
?>

<title>Prijava</title>



<form  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input type="text" name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="text" name="Opis">    
    <br><br> 

    <label><b>Broj osoba<br>   
        </b>    
    </label>    
    <input type="text"  name="BrojOsoba">    
    <br><br> 

    <label><b>Postupak<br>   
        </b>    
    </label>    
    <input type="textarea" name="Postupak">    
    <br><br> 
    <label><b>Prosječno vrijeme pripreme<br>   
        </b>    
    </label>    
    <input type="text" name="Vrijeme">    
    <br><br> 
    <label><b>Video<br>   
        </b>    
    </label>    
    <input type="text" name="Video">    
    <br><br> 


    <input type="submit" name="submitDodaj" class="NiceButton" id="buttonDodaj" value="Spremi i dalje">       






</form>

<br><br><br>

<?php }
}
