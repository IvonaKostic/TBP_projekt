<?php
/* Smarty version 4.3.1, created on 2023-07-13 15:13:04
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\prijava.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64aff860802026_16817187',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c059a79bb8d81723bc4aa92b81d4198ded18cfa1' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\prijava.tpl',
      1 => 1689253980,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64aff860802026_16817187 (Smarty_Internal_Template $_smarty_tpl) {
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Prijava</title>
    <!---Custom CSS File--->
    <link rel="stylesheet" href="css/prijava.css">
</head>

<body>
    <div class="container">
        <input type="checkbox" id="check">
        <div class="login form">
            <header>Prijava</header>
            <form id= "mojaFormaPrijava" action="prijava.php" method="post">
                <?php if ((isset($_smarty_tpl->tpl_vars['zapamtiMe']->value))) {?>
                    <input type="text" id="korisnickoIme" name="korisnickoIme" value="<?php echo $_smarty_tpl->tpl_vars['zapamtiMe']->value;?>
" placeholder="Unesi svoje korisnicko ime" maxlength="25" required>
                <?php }?>
                <?php if (!(isset($_smarty_tpl->tpl_vars['zapamtiMe']->value))) {?>
                    <input type="text" id="korisnickoIme" name="korisnickoIme" placeholder="Unesi svoje korisnicko ime" maxlength="25" required>
                <?php }?>
                <?php if ((isset($_smarty_tpl->tpl_vars['zapamtiMe']->value))) {?>
                    <input type="password" id="Lozinka" name="Lozinka" value="<?php echo $_smarty_tpl->tpl_vars['zapamtiMe']->value;?>
" placeholder="Unesis svoju lozinku" maxlength="50" required>
                <?php }?>
                <?php if (!(isset($_smarty_tpl->tpl_vars['zapamtiMe']->value))) {?>
                    <input type="password" id="Lozinka" name="Lozinka" placeholder="Unesis svoju lozinku" maxlength="50" required>
                <?php }?>
                <div class="form-row">
                    <div class="form-group">
                        <label for="zapamtiMe" class="checkbox-label">Zapamti me</label>
                        <select name="zapamtiMe" id="zapamtiMe" class="checkbox-dropdown">
                            <option value="ne">Ne</option>
                            <option value="da">Da</option>
                        </select>
                    </div>
                </div>

                <a href="zaboravljena_lozinka.php">Zaboravljena lozinka?</a>
                <input type="submit" class="submitButton" name="submitButton" form="mojaFormaPrijava" value="submit"/>
            </form>
        </div>
    </div>
</body>

<?php }
}
