<?php
/* Smarty version 4.3.1, created on 2023-07-13 15:27:31
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\reg_moji_tecajevi.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64affbc3bae422_39945866',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '916031bbc4f230679e17be563f676c9c907cb3aa' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\reg_moji_tecajevi.tpl',
      1 => 1689254849,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64affbc3bae422_39945866 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/reg_moji_tecajevi.js"><?php echo '</script'; ?>
>


<title>Moji tečajevi</title>


<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>
                <th><a style="cursor: pointer;">Početak</a></th>
                <th><a style="cursor: pointer;">Komentar</a></th>
                <th><a style="cursor: pointer;">Ocjena</a></th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php }
}
