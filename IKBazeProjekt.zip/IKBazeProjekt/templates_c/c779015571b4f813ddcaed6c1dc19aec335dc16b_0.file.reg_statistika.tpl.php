<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:21:03
  from 'C:\xampp\htdocs\moj-server\templates\reg_statistika.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_649458cfd4c4f0_93908346',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c779015571b4f813ddcaed6c1dc19aec335dc16b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\reg_statistika.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649458cfd4c4f0_93908346 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/reg_statistika.js"><?php echo '</script'; ?>
>


<title>Statistika</title>


<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Broj položenih tečajeva</a></th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] >= 3) {?>
    <h2>Moderator statistika</h2>
    <?php echo '<script'; ?>
 src="javascript/mod_statistika.js"><?php echo '</script'; ?>
>
    <div >

        <table id="tablica">
            <thead>
                <tr>
                    <th><a  style="cursor: pointer;">Korisnik</a></th>

                    <th><a style="cursor: pointer;">Broj mojih položenih tečajeva</a></th>
                </tr>
            </thead>
            <tbody id="tableBody2">
            </tbody>
        </table>
    </div>
    <h2>Moderator analiza</h2>
    <div >

        <table id="tablica">
            <thead>
                <tr>
                    <th><a  style="cursor: pointer;">Naziv jela</a></th>

                    <th><a style="cursor: pointer;">Prosjek vremena</a></th>
                    <th><a style="cursor: pointer;">Predviđeno vrijeme</a></th>

                </tr>
            </thead>
            <tbody id="tableBody3">
            </tbody>
        </table>
    </div>

    <br><br><br><br><br><br><br>
<?php }?>

<?php }
}
