<?php
/* Smarty version 4.3.1, created on 2023-07-07 20:00:34
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_novi_recept_sastojci.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64a852c28b6188_63676191',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '42205a4e40b24065c56c9d51288fc128d4b12c1e' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_novi_recept_sastojci.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a852c28b6188_63676191 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_novi_recept_sastojci.js"><?php echo '</script'; ?>
>


<title>Novi recept sastojci</title>

<button id="buttonGotovo" type="button">Gotovo</button> <br>
<div id="tablicaDiv">

    <label><b>Dostupni sastojci<br>   
        </b>    
    </label> 
    <table id="tablicaSviSastojci">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>


            </tr>
        </thead>
        <tbody id="tableBodySviSastojci">
        </tbody>
    </table>
    <label><b>Dodani sastojci<br>   
        </b>    
    </label> 
    <table id="tablicaDodaniSastojci">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>


            </tr>
        </thead>
        <tbody id="tableBodyDodaniSastojci">
        </tbody>
    </table>
    <div id="spremnik" style="visibility: hidden">
        <?php echo $_smarty_tpl->tpl_vars['spremnik']->value;?>

    </div>
</div>

<?php }
}
