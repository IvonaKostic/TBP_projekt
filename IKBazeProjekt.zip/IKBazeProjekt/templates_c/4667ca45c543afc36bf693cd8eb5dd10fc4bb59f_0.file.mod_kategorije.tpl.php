<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:21:13
  from 'C:\xampp\htdocs\moj-server\templates\mod_kategorije.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_649458d9dda789_05498004',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4667ca45c543afc36bf693cd8eb5dd10fc4bb59f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\mod_kategorije.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649458d9dda789_05498004 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_kategorije.js"><?php echo '</script'; ?>
>


<title>Kategorije</title>


<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>

            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php }
}
