<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:03:35
  from 'C:\xampp\htdocs\moj-server\templates\mod_dodaj_tecaj.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_649454b7513412_84577173',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98c963b5c16304f3db99bf3e438dade270c51d41' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\mod_dodaj_tecaj.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649454b7513412_84577173 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_dodaj_tecaj.js"><?php echo '</script'; ?>
>
<title>Novi tečaj</title>



<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input type="text" name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="text" name="Opis">    
    <br><br> 

    <label><b>Broj mjesta<br>   
        </b>    
    </label>    
    <input type="text"  name="BrojMjesta">    
    <br><br> 

    <label for="start">Rok prijave i početak:</label>

    <input type="date" id="start" name="RokPrijave">

    <br><br>     
    <label for="stop">Datum završetka:</label>

    <input type="date" id="stop" name="Kraj">

    <br><br> 
    <label for="dropdown">Recept:</label>
    <select name="recept" id="dropdown">
    </select>

    <br><br> 
    <input type="submit" name="submitDodaj" class="NiceButton" id="buttonDodaj" value="Spremi">       






</form>

<br><br><br>

<?php }
}
