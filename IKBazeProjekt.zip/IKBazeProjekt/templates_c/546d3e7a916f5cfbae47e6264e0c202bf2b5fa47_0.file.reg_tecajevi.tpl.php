<?php
/* Smarty version 4.3.1, created on 2023-06-22 17:42:51
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\reg_tecajevi.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64946bfbd47113_33281444',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '546d3e7a916f5cfbae47e6264e0c202bf2b5fa47' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\reg_tecajevi.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64946bfbd47113_33281444 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/reg_tecajevi.js"><?php echo '</script'; ?>
>


<title>Tečajevi</title>

<?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] >= 3) {?>
    <button id="buttonDodaj" type="button">Dodaj Tečaj</button> <br>
    <label for="mod">Želim moderirati odabrani tečaj</label>
    <input type="checkbox" id="mod" name="mod" value="mod">

<?php }?>
<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>

                <th><a style="cursor: pointer;">Broj mjesta</a></th>
                <th><a style="cursor: pointer;">Rok prijave</a></th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php }
}
