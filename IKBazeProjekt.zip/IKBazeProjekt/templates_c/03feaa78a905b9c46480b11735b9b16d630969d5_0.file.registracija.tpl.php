<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:26:32
  from 'C:\xampp\htdocs\moj-server\templates\registracija.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64945a18cb64d4_57060088',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '03feaa78a905b9c46480b11735b9b16d630969d5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\registracija.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64945a18cb64d4_57060088 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/registracija.js"><?php echo '</script'; ?>
>
<br>
<h1 id="registracija">Registracija</h1>
<div>
    <form id= "mojaForma" action="registracija.php" method="post">
        <label for="ime">Ime:</label>
        <input type="text" id="ime" name="ime" placeholder="Imenjak " required><br><br>

        <label for="prezime">Prezime:</label>
        <input type="text" id="prezime" name="prezime" placeholder="Prezimenić" required><br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="eMail" size="20" required placeholder="ldap@foi.hr">
        <br><br>

        <label for="korisnickoIme">Korisničko ime:</label>
        <input type="text" id="korisnickoIme" name="korisnickoIme" placeholder="IPrezimenic" maxlength="25" required><br><br>

        <label for="Lozinka">Lozinka:</label>
        <input type="password" id="Lozinka" name="Lozinka" maxlength="50" required><br/><br/>

        <label for="PotvrdaLoz">Potvrdi lozinku:</label>
        <input type="password" id="PotvrdaLoz" name="PotvrdaLoz" maxlength="50" required><br/><br/>

        <input type="checkbox" id="Terms" name="Terms" value="accept">
        <label for="Terms">Prihvaćam  <a href="#">uvjete korištenja</a></label><br> 

        <br/><br/>

    </form> 
    <div id="submitButtonDiv"><input id="submitButton" name="submitButton" type="submit" form="mojaForma" value="submit"/></div>

</div>
<?php }
}
