<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:02:45
  from 'C:\xampp\htdocs\moj-server\templates\reg_prijava_tecaja.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6494548546b886_84126508',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '90c63126829854fcdfbd8765703a59e74bd35caa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\reg_prijava_tecaja.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6494548546b886_84126508 (Smarty_Internal_Template $_smarty_tpl) {
?>

<title>Prijava tečaja</title>



<form  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['naziv']->value;?>
" disabled name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['opis']->value;?>
" disabled name="Naziv">    
    <br><br> 

    <label><b>Datum<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['datum']->value;?>
" disabled name="Naziv">    
    <br><br> 

    <label><b>Broj mjesta<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['broj_mjesta']->value;?>
" disabled name="Naziv">    
    <br><br> 
    <?php if ((isset($_smarty_tpl->tpl_vars['odjava']->value)) && $_smarty_tpl->tpl_vars['odjava']->value == true) {?>
        <input type="submit" name="submitOdjava" class="NiceButton" id="ButtonSubmitOdjava" value="Odjavi">       


    <?php }?>
   <?php if ((isset($_smarty_tpl->tpl_vars['prijava']->value)) && $_smarty_tpl->tpl_vars['prijava']->value == true) {?>
    <input type="submit" name="submit" class="NiceButton" id="ButtonSubmitPrijava" value="Prijavi">       
    <br><br>   
  <?php }?>




</form>

<br><br><br>

<?php }
}
