<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:02:39
  from 'C:\xampp\htdocs\moj-server\templates\zaglavlje.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6494547fc97284_14856156',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '885a9966a26520b9cb7fd4249aeb9cebe49edd14' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\zaglavlje.tpl',
      1 => 1675497248,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6494547fc97284_14856156 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.html to edit this template
-->
<html lang="hr">
    <head>
        <title>Projekt</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="autor" content="Ivona Koštić">
        <meta name="datum" content="3.5.2022.">
        <link rel="stylesheet" href="css/ikostic.css">
        <?php echo '<script'; ?>
 src="javascript/jquery.min.js"><?php echo '</script'; ?>
>
    </head>
    <body>
        <header>

            <div class="navbar">
                <div class="logo">
                    <a href="index.php">
                        <img alt="logo" src="materijali/foi-logo.jpg" class="logo">
                    </a>
                </div>
                <div class="dropdown">
                    <button class="dropbtn"> 
                        <img alt="logo" src="materijali/hamburger-menu-icon.png" class="logo">
                        <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                

                        <?php if (!(isset($_SESSION['uloga']))) {?>
                            <a href="prijava.php">Prijava</a>

                            <a href="registracija.php">Registracija</a>
                        <?php }?>

                        <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] >= 3) {?>
                            <a href="mod_kategorije.php">Prikaz kategorija</a>
                            <a href="mod_jela.php">Jela</a>
                        <?php }?>
                        <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] == 4) {?>
                            <a href="admin_upravljanje_moderatori.php">Upravljanje moderatorima</a>
                            <a href="admin_upravljanje_korisnici.php">Upravljanje korisnicima</a>
                        <?php }?>

                        <?php if ((isset($_SESSION['uloga']))) {?>
                            <a href="reg_tecajevi.php">Tečajevi</a>
                            <a href="reg_moji_tecajevi.php">Moji tečajevi</a>
                            <a href="reg_statistika.php">Moja statistika</a>
                            <a href="odjava.php">Odjava</a>
                        <?php }?>
                    </div>
                </div> 
            </div>
<?php }
}
