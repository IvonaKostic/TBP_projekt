<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:02:39
  from 'C:\xampp\htdocs\moj-server\templates\reg_tecajevi.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6494547fd1c388_07145425',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a20077398257a9b39f4f1ff6a9f4f389d716429f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\reg_tecajevi.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6494547fd1c388_07145425 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/reg_tecajevi.js"><?php echo '</script'; ?>
>


<title>Tečajevi</title>

<?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] >= 3) {?>
    <button id="buttonDodaj" type="button">Dodaj Tečaj</button> <br>
    <label for="mod">Želim moderirati odabrani tečaj</label>
    <input type="checkbox" id="mod" name="mod" value="mod">

<?php }?>
<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>

                <th><a style="cursor: pointer;">Broj mjesta</a></th>
                <th><a style="cursor: pointer;">Rok prijave</a></th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php }
}
