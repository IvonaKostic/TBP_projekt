<?php
/* Smarty version 4.3.1, created on 2023-07-03 16:09:39
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_kat_recepti.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64a2d6a3d9df30_13467476',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '772853aed3ae56550e7e9378a877139f29f00b54' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_kat_recepti.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2d6a3d9df30_13467476 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_kat_recepti.js"><?php echo '</script'; ?>
>


<title>Recepti</title>

<button id="buttonDodaj" type="button">Dodaj recept</button> <br>
<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>
                <th><a style="cursor: pointer;">Broj osoba</a></th>

            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>

    <div id="spremnik" style="visibility: hidden">
        <?php echo $_smarty_tpl->tpl_vars['spremnik']->value;?>

    </div>
</div>

<?php }
}
