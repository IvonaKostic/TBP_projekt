<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:26:29
  from 'C:\xampp\htdocs\moj-server\templates\prijava.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64945a15ee03f0_04655335',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1e703ee02607d5144b8e857a2461968cdc892e4b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\prijava.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64945a15ee03f0_04655335 (Smarty_Internal_Template $_smarty_tpl) {
?><h1 id="prijava">Prijava</h1>

</header>
<div>
    <form id= "mojaFormaPrijava" action="prijava.php" method="post">

        <?php if ((isset($_smarty_tpl->tpl_vars['zapamtiMe']->value))) {?>
            <label for="korisnickoIme">Korisničko ime:</label>
            <input type="text" id="korisnickoIme" name="korisnickoIme" value="<?php echo $_smarty_tpl->tpl_vars['zapamtiMe']->value;?>
" placeholder="IPrezimenic" maxlength="25" required><br><br>
        <?php }?>
        <?php if (!(isset($_smarty_tpl->tpl_vars['zapamtiMe']->value))) {?>
            <label for="korisnickoIme">Korisničko ime:</label>
            <input type="text" id="korisnickoIme" name="korisnickoIme" placeholder="IPrezimenic" maxlength="25" required><br><br>
        <?php }?>
        <label for="Lozinka">Lozinka:</label>
        <input type="password" id="Lozinka" name="Lozinka" maxlength="50" required><br/><br/>

        <label for="zapamtiMe">Zapamti me?</label>
        <select name="zapamtiMe" id="zapamtiMe">
            <option value="ne" >Ne</option>
            <option value="da">Da</option>
        </select> 

        <br/><br/>

    </form> 
    <input type="submit" id="submitButton" name="submitButton" form="mojaFormaPrijava" value="submit"/>
    <br/><br/>
    <a href="zaboravljena_lozinka.php">Zaboravljena lozinka?</a>
</div>
<?php }
}
