<?php
/* Smarty version 4.3.1, created on 2023-07-12 21:47:21
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\zaglavlje.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64af0349bf9db2_43866975',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8cfe04655a847334f79a1f2d59bc62aba16d05c0' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\zaglavlje.tpl',
      1 => 1689191220,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64af0349bf9db2_43866975 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.html to edit this template
-->
<html lang="hr">
    <head>
        <title>Projekt</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="autor" content="Ivona Koštić">
        <meta name="datum" content="3.5.2023.">
        <link rel="stylesheet" href="css/ikostic.css">
        <?php echo '<script'; ?>
 src="javascript/jquery.min.js"><?php echo '</script'; ?>
>
    </head>
    <body>
        <header>

            <div class="navbar">
                <div class="logo">
                    <a href="index.php">
                        <img alt="logo" src="materijali/foi-logo.jpg" class="logo">
                    </a>
                </div>
                <div class="dropdown">
                    <button class="dropbtn"> 
                        <img alt="logo" src="materijali/hamburger-menu-icon.png" class="logo">
                        <i class="fa fa-caret-down"></i>
                    </button>
                    <div class="dropdown-content">
                

                        <?php if (!(isset($_SESSION['uloga']))) {?>
                            <a href="prijava.php">Prijava</a>

                            <a href="registracija.php">Registracija</a>
                        <?php }?>

                        <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] >= 3) {?>
                            <a href="mod_kategorije.php">Prikaz kategorija</a>
                            <a href="mod_jela.php">Jela</a>
                        <?php }?>
                        <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] == 4) {?>
                            <a href="admin_upravljanje_korisnici.php">Upravljanje korisnicima</a>
                        <?php }?>

                        <?php if ((isset($_SESSION['uloga']))) {?>
                            <a href="reg_tecajevi.php">Tečajevi</a>
                            <a href="reg_moji_tecajevi.php">Moji tečajevi</a>
                            <a href="reg_statistika.php">Moja statistika</a>
                            <a href="odjava.php">Odjava</a>
                        <?php }?>
                    </div>
                </div> 
            </div>
<?php }
}
