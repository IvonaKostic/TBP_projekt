<?php
/* Smarty version 4.3.1, created on 2023-06-22 17:43:11
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\reg_prijava_tecaja.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64946c0f901bb0_32858713',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e18e2d0f10398f6a755ee8be8f451597be2bead0' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\reg_prijava_tecaja.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64946c0f901bb0_32858713 (Smarty_Internal_Template $_smarty_tpl) {
?>

<title>Prijava tečaja</title>



<form  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['naziv']->value;?>
" disabled name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['opis']->value;?>
" disabled name="Naziv">    
    <br><br> 

    <label><b>Datum<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['datum']->value;?>
" disabled name="Naziv">    
    <br><br> 

    <label><b>Broj mjesta<br>   
        </b>    
    </label>    
    <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['broj_mjesta']->value;?>
" disabled name="Naziv">    
    <br><br> 
    <?php if ((isset($_smarty_tpl->tpl_vars['odjava']->value)) && $_smarty_tpl->tpl_vars['odjava']->value == true) {?>
        <input type="submit" name="submitOdjava" class="NiceButton" id="ButtonSubmitOdjava" value="Odjavi">       


    <?php }?>
   <?php if ((isset($_smarty_tpl->tpl_vars['prijava']->value)) && $_smarty_tpl->tpl_vars['prijava']->value == true) {?>
    <input type="submit" name="submit" class="NiceButton" id="ButtonSubmitPrijava" value="Prijavi">       
    <br><br>   
  <?php }?>




</form>

<br><br><br>

<?php }
}
