<?php
/* Smarty version 4.3.1, created on 2023-07-10 23:18:34
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_kat_recepti_view.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64ac75aab43bb1_45113606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'da097f3d09727bc5264609d6baaef26a2773da82' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_kat_recepti_view.tpl',
      1 => 1689023911,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64ac75aab43bb1_45113606 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_kat_recepti_view.js"><?php echo '</script'; ?>
>




<title>Pregled i ažuriranje recepta</title>



<form  method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input value="<?php echo $_smarty_tpl->tpl_vars['naziv']->value;?>
" type="text" name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input value="<?php echo $_smarty_tpl->tpl_vars['opis']->value;?>
" type="text" name="Opis">    
    <br><br> 

    <label><b>Broj osoba<br>   
        </b>    
    </label>    
    <input value="<?php echo $_smarty_tpl->tpl_vars['brosoba']->value;?>
" type="text"  name="BrojOsoba">    
    <br><br> 

    <label><b>Postupak<br>   
        </b>    
    </label>    
    <input value="<?php echo $_smarty_tpl->tpl_vars['postupak']->value;?>
" type="textarea" name="Postupak">    
    <br><br> 
    <label><b>Video<br>   
        </b>    
    </label>    
    <input value="<?php echo $_smarty_tpl->tpl_vars['video']->value;?>
" type="text" name="Video">    
    <br><br> 

    <div id="tablicaDiv">

        <label><b>Dostupni sastojci<br>   
            </b>    
        </label> 
        <table id="tablicaSviSastojci">
            <thead>
                <tr>
                    <th><a  style="cursor: pointer;">Naziv</a></th>

                    <th><a style="cursor: pointer;">Opis</a></th>


                </tr>
            </thead>
            <tbody id="tableBodySviSastojci">
            </tbody>
        </table>
        <label><b>Dodani sastojci<br>   
            </b>    
        </label> 
        <table id="tablicaDodaniSastojci">
            <thead>
                <tr>
                    <th><a  style="cursor: pointer;">Naziv</a></th>

                    <th><a style="cursor: pointer;">Opis</a></th>


                </tr>
            </thead>
            <tbody id="tableBodyDodaniSastojci">
            </tbody>
        </table>
        <div id="spremnik" style="visibility: hidden">
            <?php echo $_smarty_tpl->tpl_vars['spremnik']->value;?>

        </div>
    </div>
    <br><br>
    <input type="submit" name="submitDodaj" class="NiceButton" id="buttonDodaj" value="Spremi">  
    <button id="buttonBrisi" type="button" name="buttonBrisi">Briši recept</button> <br>
    <br><br> <br><br> <br><br>





</form>

<br><br><br>


<?php }
}
