<?php
/* Smarty version 4.3.1, created on 2023-07-03 16:08:07
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_dodaj_tecaj.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64a2d647276cb7_13698245',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '537cc0f89e3e517bce5ff3bd8b3157965b7d2305' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_dodaj_tecaj.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64a2d647276cb7_13698245 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_dodaj_tecaj.js"><?php echo '</script'; ?>
>
<title>Novi tečaj</title>



<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>
">    
    <br><br>
    <label><b>Naziv<br>   
        </b>    
    </label>    
    <input type="text" name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="text" name="Opis">    
    <br><br> 

    <label><b>Broj mjesta<br>   
        </b>    
    </label>    
    <input type="text"  name="BrojMjesta">    
    <br><br> 

    <label for="start">Rok prijave i početak:</label>

    <input type="date" id="start" name="RokPrijave">

    <br><br>     
    <label for="stop">Datum završetka:</label>

    <input type="date" id="stop" name="Kraj">

    <br><br> 
    <label for="dropdown">Recept:</label>
    <select name="recept" id="dropdown">
    </select>

    <br><br> 
    <input type="submit" name="submitDodaj" class="NiceButton" id="buttonDodaj" value="Spremi">       






</form>

<br><br><br>

<?php }
}
