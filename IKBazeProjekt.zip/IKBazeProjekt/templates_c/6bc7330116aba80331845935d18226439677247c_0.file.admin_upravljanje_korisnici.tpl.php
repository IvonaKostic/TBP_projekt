<?php
/* Smarty version 4.3.1, created on 2023-07-10 22:30:08
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\admin_upravljanje_korisnici.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64ac6a5011eb23_55607128',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6bc7330116aba80331845935d18226439677247c' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\admin_upravljanje_korisnici.tpl',
      1 => 1689021004,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64ac6a5011eb23_55607128 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/admin_upravljanje_korisnici.js"><?php echo '</script'; ?>
>

<title>Moderatori</title>

<div id="tablicaDiv">
    <table id="tablica">
        <thead>
            <tr>
                <th><a style="cursor: pointer;">Ime Prezime</a></th>
                <th><a style="cursor: pointer;">Korime</a></th>
                <th><a style="cursor: pointer;">ID</a></th>
                <th><a style="cursor: pointer;">Uloga</a></th>
                <th><a style="cursor: pointer;">Datum registracije</a></th>
                <th><a style="cursor: pointer;">Omogućen</a></th>
                <th>Akcija</th>
                <th>Brisanje</th>admin
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>
<?php }
}
