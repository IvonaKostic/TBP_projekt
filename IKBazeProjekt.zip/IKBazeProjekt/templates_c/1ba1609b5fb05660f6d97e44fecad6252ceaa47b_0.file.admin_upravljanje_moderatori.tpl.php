<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:53:24
  from 'C:\xampp\htdocs\moj-server\templates\admin_upravljanje_moderatori.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_649460649da895_10923873',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1ba1609b5fb05660f6d97e44fecad6252ceaa47b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\admin_upravljanje_moderatori.tpl',
      1 => 1675498156,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_649460649da895_10923873 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/admin_upravljanje_moderatori.js"><?php echo '</script'; ?>
>


<title>Moderatori</title>


<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Korisnik</a></th>

                <th><a style="cursor: pointer;">Recept</a></th>
                <th><a style="cursor: pointer;">Ocjena</a></th>
                <th><a style="cursor: pointer;">Komentar</a></th>
                <th><a style="cursor: pointer;">Slika</a></th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>


<?php }
}
