<?php
/* Smarty version 4.3.1, created on 2023-07-16 23:10:01
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\registracija.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64b45ca94b0b07_26349052',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c0c6cb638975396c11c4dc5256a8ae79965044f8' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\registracija.tpl',
      1 => 1689541761,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64b45ca94b0b07_26349052 (Smarty_Internal_Template $_smarty_tpl) {
?><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registracija</title>
    <!---Custom CSS File--->
    <?php echo '<script'; ?>
 src="javascript/registracija.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" href="css/registracija.css">

</head>

<body>
    <div class="container">
        <input type="checkbox" id="check">
        <div class="registration form">
            <header>Registracija</header>
            <form id= "mojaForma" action="registracija.php" method="post">
                <input type="text" id="ime" name="ime" placeholder="Unesi svoje ime" required>
                <input type="text" id="prezime" name="prezime" placeholder="Unesi svoje prezime" required>
                <input type="text" id="email" name="eMail" size="20" required placeholder="ldap@foi.hr">
                <input type="text" id="korisnickoIme" name="korisnickoIme" placeholder="Kreiraj korisnicko ime" maxlength="25" required>
                <input type="password" id="Lozinka" name="Lozinka" maxlength="50" placeholder="Kreiraj lozinku" required>
                <input type="password" id="PotvrdaLoz" name="PotvrdaLoz" maxlength="50" placeholder="Potvrdi svoju lozinku" required>
                <div class="form-row">
                    <div class="form-group">
                        <input type="checkbox" id="Terms" name="Terms" value="accept">
                        <label for="Terms"><a href="#">Prihvaćam uvjete korištenja</a></label><br> 
                    </div>
                </div>
                <input name="submitButton" type="submit" form="mojaForma" value="submit" id="submitButton">
            </form>
        </div>
    </div>


</body>

<?php }
}
