<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:39:46
  from 'C:\xampp\htdocs\moj-server\templates\reg_tecaj_recepti.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64945d321da3c9_91901433',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '967a68e821598798f089c267f6bb9ea69c83f8b5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\reg_tecaj_recepti.tpl',
      1 => 1675409354,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64945d321da3c9_91901433 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/reg_tecaj_recepti.js"><?php echo '</script'; ?>
>


<title>Recept</title>


<div id="tablicaDiv">

    <br><br>
    <label><b>Naziv jela<br>   
        </b>    
    </label>    
    <input type="text" id="naziv" disabled name="Naziv">    
    <br><br> 

    <label><b>Opis<br>   
        </b>    
    </label>    
    <input type="textarea" rows="4" cols="50" id="opis" disabled name="Naziv">    
    <br><br> 

    <label><b>Postupak<br>   
        </b>    
    </label>    
    <input type="textarea" rows="4" cols="50" id="postupak" disabled name="Naziv">    
    <br><br> 

    <label><b>Broj osoba<br>   
        </b>    
    </label>    
    <input type="text" id="brosoba" disabled name="Naziv">    
    <br><br> 
    <label><b>Sastojci<br>   
        </b>    
    </label> 
    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>
                <th><a style="cursor: pointer;">Količina</a></th>

            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
    <div id="formaDodavanje">

    </div>
    <label><b>Video uputa<br>   
        </b>    
    </label> 
    <br><br> 
    <iframe class="cijeli" id="video" onload="resizeIframe(this) src =""></iframe> 
    <br><br> 


    <br><br> 
    <br><br> 
    <br><br> 
    <div id="spremnik" style="visibility: hidden">
        <?php echo $_smarty_tpl->tpl_vars['spremnik']->value;?>

    </div>
</div>

<?php }
}
