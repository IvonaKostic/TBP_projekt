<?php
/* Smarty version 4.3.1, created on 2023-07-10 22:16:24
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\admin_upravljanje_korisnik_edit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64ac6718e91596_74008376',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3857d09dcdb4017835313cb33e93e858462d2517' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\admin_upravljanje_korisnik_edit.tpl',
      1 => 1688830112,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64ac6718e91596_74008376 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/admin_upravljanje_moderatori.js"><?php echo '</script'; ?>
>

<title>Moderatori</title>

<div id="tablicaDiv">
    <table id="tablica">
        <thead>
            <tr>
                <th><a style="cursor: pointer;">Ime Prezime</a></th>
                <th><a style="cursor: pointer;">Korime</a></th>
                <th><a style="cursor: pointer;">ID</a></th>
                <th><a style="cursor: pointer;">Uloga</a></th>
                <th><a style="cursor: pointer;">Datum registracije</a></th>
                <th><a style="cursor: pointer;">Omogućen</a></th>
                <th>Akcija</th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>
<?php }
}
