<?php
/* Smarty version 4.3.1, created on 2023-06-22 16:53:26
  from 'C:\xampp\htdocs\moj-server\templates\admin_upravljanje_korisnici.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6494606625dea8_37604464',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a5efb43b107996fd344e06e0a08b9299ccd4a0ab' => 
    array (
      0 => 'C:\\xampp\\htdocs\\moj-server\\templates\\admin_upravljanje_korisnici.tpl',
      1 => 1675510392,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6494606625dea8_37604464 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/admin_upravljanje_korisnici.js"><?php echo '</script'; ?>
>

<title>Moderatori</title>

<div id="tablicaDiv">
    <table id="tablica">
        <thead>
            <tr>
                <th><a style="cursor: pointer;">Ime Prezime</a></th>
                <th><a style="cursor: pointer;">Korime</a></th>
                <th><a style="cursor: pointer;">ID</a></th>
                <th><a style="cursor: pointer;">Uloga</a></th>
                <th><a style="cursor: pointer;">Datum registracije</a></th>
                <th><a style="cursor: pointer;">Omogućen</a></th>
                <th>Akcija</th>
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>
<?php }
}
