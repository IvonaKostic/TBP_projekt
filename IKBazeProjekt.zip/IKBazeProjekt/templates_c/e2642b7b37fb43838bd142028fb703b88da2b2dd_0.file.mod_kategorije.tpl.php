<?php
/* Smarty version 4.3.1, created on 2023-06-22 17:50:44
  from 'D:\Programii\xampp\htdocs\IKBazeProjekt\templates\mod_kategorije.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64946dd44fe2c9_39434281',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2642b7b37fb43838bd142028fb703b88da2b2dd' => 
    array (
      0 => 'D:\\Programii\\xampp\\htdocs\\IKBazeProjekt\\templates\\mod_kategorije.tpl',
      1 => 1687447884,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64946dd44fe2c9_39434281 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 src="javascript/mod_kategorije.js"><?php echo '</script'; ?>
>


<title>Kategorije</title>


<div id="tablicaDiv">

    <table id="tablica">
        <thead>
            <tr>
                <th><a  style="cursor: pointer;">Naziv</a></th>

                <th><a style="cursor: pointer;">Opis</a></th>

            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<?php }
}
