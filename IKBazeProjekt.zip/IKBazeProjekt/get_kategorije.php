<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $podaci = array();

    $veza = new Baza();
    $veza->spojiDB();
    $id_korisnik = $_GET[id_korisnik];
    $upit = "SELECT kategorije.id_kategorija, kategorije.naziv, kategorije.opis, COALESCE(MODERIRA.id_korisnik, 0) AS moderirano
FROM kategorije
         LEFT JOIN MODERIRA ON kategorije.id_kategorija = MODERIRA.id_kategorija
    AND MODERIRA.id_korisnik = {$id_korisnik};
";
    $rezultat = $veza->selectDB($upit);
    $rezultat = pg_fetch_all($rezultat);

    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    $veza->zatvoriDB();
    echo json_encode($podaci);
}