<?php

require 'zaglavlje.php';

$smarty->display('registracija.tpl');

require 'podnozje.php';

if (isset($_POST["submitButton"])) {
    $korime = $_POST["korisnickoIme"];
    $ime = $_POST["ime"];
    $prezime = $_POST["prezime"];
    $lozinka = $_POST["Lozinka"];
    $ponlozinka = $_POST["PotvrdaLoz"];
    $email = $_POST["eMail"];

    if (validacijaSve($korime, $ime, $prezime, $lozinka, $ponlozinka, $email)) {
        fb("validacija prolaz");
        $registracija = new Registracija();
        $baza = new Baza();
        $baza->spojiDB();

        try {
            $result = $registracija->registriraj($korime, $email, $lozinka, $ime, $prezime, $baza);
            fb("rezultat " . $result);
            if ($result != null) {
                $poslan = $registracija->posaljiEmail($korime, $email, $baza);
                if ($poslan) {
                    echo 'Poslan je email';
                }
            }
        } catch (Exception $e) {
            echo '<script>alert("' . $e->getMessage() . '");</script>'; // Display the exception message as an alert
        }
    }
}

function validacijaSve($korime, $ime, $prezime, $lozinka, $ponlozinka, $email) {
    $regex = "/^[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*$/";
    $regex_res = preg_match($regex, $korime);
    if (!$regex_res) {
        return false;
    }
    $regex = "/^[a-z ,.'-]+$/i";
    $regex_res = preg_match($regex, $ime);
    if (!$regex_res) {
        return false;
    }
    $regex = "/([A-Z][a-zA-Z]*)/";
    $regex_res = preg_match($regex, $prezime);
    if (!$regex_res) {
        return false;
    }
    $regex = "/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{5,}$/";
    $regex_res = preg_match($regex, $lozinka);

    if (!$regex_res) {
        return false;
    }
    if ($lozinka != $ponlozinka) {
        return false;
    }

    return true;
}
