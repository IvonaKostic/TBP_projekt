<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] == 4) {

    $baza = new Baza();
    $baza->spojiDB();
    $ime = $_GET["ime"];
    $prezime = $_GET["prezime"];
    $korime = $_GET["korime"];
    $id_korisnik = $_GET["id_korisnik"];
    $uloga = $_GET["uloga"];
    $omogucen = $_GET["omogucen"];
    ob_start();
    fb("korisnik id ".$id_korisnik);
    $upit = "UPDATE KORISNICI SET ime='{$ime}',prezime='{$prezime}',korime='{$korime}',\"ULOGE_id_uloga\"={$uloga},omogucen=1 WHERE id_korisnik={$id_korisnik}";
    $baza->updateDB($upit);

    echo json_encode("gotovo");
    $baza->zatvoriDB();
}
?>