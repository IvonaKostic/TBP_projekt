<?php

require 'korijen.php';

ob_start();
$veza = pg_connect("host=localhost port=5433 dbname=postgres1 user=postgres password=postgres");
echo var_dump($veza);
$result = pg_query($veza, "SELECT * FROM korisnici");
echo var_dump(pg_fetch_all($result));
$result_aray = pg_fetch_all($result);
echo "<br>Halo<br>";
while ($row = pg_fetch_row($result)) {
    echo "Author: $row[0]  E-mail: $row[1]";
    echo "<br />\n";
}

echo "<br> ". $result_aray["lozinka_sha1"];
