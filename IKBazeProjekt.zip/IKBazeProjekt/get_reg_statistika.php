<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $sadrzaj = array();
    $korime = $_SESSION["korisnik"];

    $baza = new Baza();
    $baza->spojiDB();
    require 'korisnik_id.php';

    $upit = "SELECT k.naziv, (SELECT COUNT(*) FROM TECAJEVI t, PRIJAVLJUJE p WHERE t.id_kategorija = k.id_kategorija AND p.ocjena > 1 AND p.\"KORISNICI_id_korisnik\" = {$korisnik_id} AND p.\"TECAJEVI_id_tecaj\" = t.id_tecaj) as zbroj FROM KATEGORIJE k";
    $rezultat = $baza->selectDB($upit);

    while ($row = pg_fetch_assoc($rezultat)) {
        $sadrzaj[] = $row;
    }
    echo json_encode($sadrzaj);
    $baza->zatvoriDB();
}