<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $sadrzaj = array();
    $korime = $_SESSION["korisnik"];

    $baza = new Baza();
    $baza->spojiDB();

    $upit = "SELECT * FROM SLIJEDI_RECEPT sr
         JOIN KORISNICI k ON sr.korisnik_id = k.id_korisnik
         JOIN RECEPTI r ON sr.recept_id = r.id_recept";
    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

  while ($red = pg_fetch_assoc($rezultat)) {
        $sadrzaj[] = $red;
    }

    echo json_encode($sadrzaj);
}
