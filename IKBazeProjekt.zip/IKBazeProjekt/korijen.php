<?php

$putanja = realpath(".");

require $putanja . '/baza.class.php';
require $putanja . '/sesija.class.php';
require $putanja . '/vanjske_biblioteke/smarty-4.3.1/libs/Smarty.class.php';
require $putanja . '/vanjske_biblioteke/FirePHPCore/fb.php';
require $putanja . '/registracija.class.php';

ob_start();

Sesija::kreirajSesiju();