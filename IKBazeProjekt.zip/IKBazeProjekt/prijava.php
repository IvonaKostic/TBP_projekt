<?php

//if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
//    $location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
//    //header('HTTP/1.1 301 Moved Permanently');
//    header('Location: ' . $location);
//    exit;
//}

require 'zaglavlje.php';
if (isset($_COOKIE["zapamtiMe"])) {
    $smarty->assign('zapamtiMe', $_COOKIE["zapamtiMe"]);
}
//echo phpinfo();
$smarty->display('prijava.tpl');
require 'podnozje.php';

if (isset($_POST["submitButton"])) {
    $korime = $_POST["korisnickoIme"];
    $lozinka = $_POST["Lozinka"];
    $zapamtiMe = $_POST["zapamtiMe"];
    if ($zapamtiMe == "da") {
        setcookie("zapamtiMe", $korime);
    }

    $upit = "SELECT * FROM KORISNICI WHERE korime = '{$korime}'";
    $baza = new Baza();
    $baza->spojiDB();
     
    $result = $baza->selectDB($upit);
    ob_start();
    fb($result);
    //$result_array = mysqli_fetch_assoc($result);
    $result_array = pg_fetch_assoc($result);
    if (isset($result_array["sol"])) {
        $broj_pokusaja = $result_array["broj_pokusaja"];
        $lozinka_hash = $result_array["lozinka_sha1"];
        $sol = $result_array["sol"];
        if (hash('sha1', $sol . $lozinka) === $lozinka_hash && $result_array["omogucen"] === "1") {
            Sesija::kreirajKorisnika($result_array["korime"], $result_array["ULOGE_id_uloga"]);
            $upit = "UPDATE KORISNICI SET broj_pokusaja = 0 WHERE korime = '{$korime}'";
            $baza->updateDB($upit);
            fb($_SESSION["uloga"] . "je uloga");
            header("Location: index.php");
        } else if ($result_array["omogucen"] === "1") {
            if ($broj_pokusaja < 2) {
                $broj_pokusaja = $broj_pokusaja + 1;
                $upit = "UPDATE KORISNICI SET broj_pokusaja = {$broj_pokusaja} WHERE korime = '{$korime}'";
                echo "Broj pokušaja " . $broj_pokusaja . " ide se do 3 onda disabled";
                $baza->updateDB($upit);
            } else {
                $upit = "UPDATE KORISNICI SET omogucen = 0 WHERE korime = '{$korime}'";
                $baza->updateDB($upit);
                echo "Korisnik je onemogućen";
            }
        } else {
            echo "Korisnik je onemogućen, ne može se logirati";
        }
    }
    $baza->zatvoriDB();
}
