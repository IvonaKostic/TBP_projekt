<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $podaci = array();
    $id_recept = $_GET["id"];
    $veza = new Baza();
    $veza->spojiDB();
    $id_tecaj = $_GET["id"];

    $upit = "SELECT * FROM RECEPTI r, SADRZI_SASTOJAK s, SASTOJCI sa WHERE r.id_recept = {$id_recept} AND s.\"RECEPTI_id_recept\" = r.id_recept AND s.\"SASTOJCI_id_sastojak\" = sa.id_sastojak";
    $rezultat = $veza->selectDB($upit);
    $veza->zatvoriDB();

    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    echo json_encode($podaci);
}