$(document).ready(function () {



    $("#buttonGotovo").click(function () {
        window.location = "mod_kategorije.php";
    });
    $("#buttonBrisi").click(function () {

        let idRecept = $("#spremnik").html();

        $.ajax({
            type: "get",
            url: "delete_mod_recept.php",
            data: {
                id: idRecept,

            },
            dataType: "json",
            success: function (response) {
                window.location = "mod_kategorije.php";

            }
        });

    });


    ispisiSve();
    ispisiDodane();


});
function ispisiSve() {
    $.ajax({
        type: "get",
        url: "get_mod_sastojci.php",
        data: {

        },
        dataType: "json",
        success: function (response) {
            var tablicaHtml = "";

            $.each(response, function (key, val) {

                tablicaHtml +=
                        "<tr data-id=\"" + val.id_sastojak + "\" onclick=\"" + "klikDodaj(this)" + "\">"
                        + "<td>" + val.naziv + "</td>"
                        + "<td>" + val.opis + "</td>"

                        + "</tr>";
            });
            $("#tableBodySviSastojci").html(tablicaHtml);

        }
    });
}
function ispisiDodane() {
    let idRecept = $("#spremnik").html();
    $.ajax({
        type: "get",
        url: "get_mod_recept_sastojci.php",
        data: {
            id: idRecept
        },
        dataType: "json",
        success: function (response) {
            var tablicaHtml = "";

            $.each(response, function (key, val) {

                tablicaHtml +=
                        "<tr data-id=\"" + val.id_sastojak + "\" onclick=\"" + "klikMakni(this)" + "\">"
                        + "<td>" + val.naziv + "</td>"
                        + "<td>" + val.opis + "</td>"

                        + "</tr>";
            });
            $("#tableBodyDodaniSastojci").html(tablicaHtml);

        }
    });
}

function klikDodaj(data) {
    let id = $(data).data("id");
    let idRecept = $("#spremnik").html();
    let kolicina = prompt("Unesite količinu (Samo brojčano):", "5");
    let mj = prompt("Mjerna jedinica:", "KOM");
    $.ajax({
        type: "get",
        url: "push_mod_recept_sastojak.php",
        data: {
            id: id,
            idrec: idRecept,
            kol: kolicina,
            mj: mj
        },
        dataType: "json",
        success: function (response) {
            console.log(response);
            //ispisiSve();
            ispisiDodane();

        }
    });

}

function klikMakni(data) {
    let id = $(data).data("id");
    let idRecept = $("#spremnik").html();
    $.ajax({
        type: "get",
        url: "delete_mod_recept_sastojak.php",
        data: {
            id: id,
            idrec: idRecept

        },
        dataType: "json",
        success: function (response) {
            console.log(response);
            //ispisiSve();
            ispisiDodane();

        }
    });

}