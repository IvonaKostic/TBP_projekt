$(document).ready(function () {



    function ispisi() {
        $.ajax({
            type: "get",
            url: "get_reg_statistika.php",
            data: {

            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";

                $.each(response, function (key, val) {
                  
                    tablicaHtml +=
                            "<tr>"
                            + "<td>" + val.naziv + "</td>"
                            + "<td>" + val.zbroj + "</td>"

                            + "</tr>";
                });
                $("#tableBody").html(tablicaHtml);

            }
        });
    }

    ispisi();



});


