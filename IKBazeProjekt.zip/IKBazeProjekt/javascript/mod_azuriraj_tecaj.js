$(document).ready(function () {


    ispisi();

});
function ispisi() {
    $.ajax({
        type: "get",
        url: "get_mod_recepti.php",
        data: {

        },
        dataType: "json",
        success: function (response) {
            var divHTML = "";

            $.each(response, function (key, val) {

                divHTML +=
                        "<option value=\"" + val.id_recept + "\">" + val.naziv_jela + "</option>";
            });
            $("#dropdown").html(divHTML);

        }
    });
}
