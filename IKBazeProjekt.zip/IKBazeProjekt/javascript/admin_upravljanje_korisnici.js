$(document).ready(function () {
    ispisi();

    $(document).on("click", ".delete-button", function () {
        var idKorisnik = $(this).closest(".user-row").data("kid");
        deleteKorisnik(idKorisnik);
    });
});
function klik(podaci) {
    window.location = 'admin_upravljanje_korisnik_edit.php?id=' + $(podaci).data("id");
}

function ispisi() {
    $.ajax({
        type: "get",
        url: "get_korisnici.php",
        data: {},
        dataType: "json",
        success: function (response) {
            var tablicaHtml = "";
            $.each(response, function (key, val) {
                tablicaHtml +=
                        "<tr class='user-row' data-kid='" + val.id_korisnik + "' onclick='showEditForm(this)'>" +
                        "<td>" + val.ime + " " + val.prezime + "</td>" +
                        "<td>" + val.korime + "</td>" +
                        "<td>" + val.id_korisnik + "</td>" +
                        "<td>" + val.naziv + "</td>" +
                        "<td>" + val.datum_registracije + "</td>" +
                        "<td>" + val.omogucen + "</td>" +
                        "<td><button class='edit-button'>Uredi</button></td>" +
                        "<td><button class='delete-button' onclick='deleteKorisnik(" + val.id_korisnik + ")'>Obrisi</button></td>" +
                        "</tr>" +
                        "<tr class='user-edit-form' id='editForm-" + val.id_korisnik + "' style='display: none;'>" +
                        "<td colspan='7'>" +
                        "<input type='text' name='ime' value='" + val.ime + "'>" +
                        "<input type='text' name='prezime' value='" + val.prezime + "'>" +
                        "<input type='text' name='korime' value='" + val.korime + "'>" +
                        "<input type='text' name='id_korisnik' value='" + val.id_korisnik + "' disabled>" +
                        "<select name='naziv' onchange='showCategories(" + val.id_korisnik + ",this)'>" +
                        "<option value='2'>Registrirani korisnik</option>" +
                        "<option value='3'>Moderator</option>" +
                        "<option value='4'>Administrator</option>" +
                        "</select>" +
                        "<input type='text' name='datum_registracije' value='" + val.datum_registracije + "' disabled>" +
                        "<select name='omogucen'>" +
                        "<option value='1'>Omogućen</option>" +
                        "<option value='0'>Onemogućen</option>" +
                        "</select>" +
                        "<div id='div-'" + val.id_korisnik + "></div>" +
                        "<button class='save-button' onclick=\"saveEdit(" + val.id_korisnik + ")\">Spremi</button>" +
                        "</td>" +
                        "</tr>";
            });
            $("#tableBody").html(tablicaHtml);
        }
    });
}

function showEditForm(podaci) {

    $("#editForm-" + $(podaci).data("kid")).show();
}

function showCategories(idKorisnik, data) {
    $("#div-" + idKorisnik).show();
    $("#div-" + idKorisnik).html();
    console.log(idKorisnik + "ID");
    $.ajax({
        type: "GET",
        url: "get_kategorije.php",
        data: {
            id_korisnik: idKorisnik
        },
        success: function (response) {
            var selectHtml = "<select name='kategorije' multiple='multiple'>";
            $.each(response, function (key, val) {
                var selected = (val.moderira == 1) ? "selected" : "";
                selectHtml += "<option value='" + val.id_kategorija + "' " + selected + ">" + val.naziv + "</option>";
            });
            selectHtml += "</select>";
            $("#div-" + idKorisnik).html(selectHtml);
        }
    });

}

function saveEdit(idKorisnik) {
    var ime = $("#editForm-" + idKorisnik + " input[name='ime']").val();
    var prezime = $("#editForm-" + idKorisnik + " input[name='prezime']").val();
    var korime = $("#editForm-" + idKorisnik + " input[name='korime']").val();
    var uloga = $("#editForm-" + idKorisnik + " select[name='naziv']").val();
    var omogucen = $("#editForm-" + idKorisnik + " select[name='omogucen']").val();
    var id_korisnik = $("#editForm-" + idKorisnik + " input[name='id_korisnik']").val();
    $.ajax({
        type: "GET",
        url: "push_admin_update_korisnik.php",
        data: {
            ime: ime,
            prezime: prezime,
            korime: korime,
            uloga: uloga,
            omogucen: omogucen,
            id_korisnik: id_korisnik
        },
        success: function (response) {
            console.log(response);
        }
    });
    ispisi();
}

function deleteKorisnik(idKorisnik) {
    console.log("Deleting user with id:", idKorisnik); // Log the id_korisnik value
    if (confirm("Jeste li sigurni da želite obrisati korisnika?")) {
        $.ajax({
            type: "GET",
            url: "delete_korisnik.php",
            data: {
                id_korisnik: idKorisnik
            },
            success: function (response) {
                console.log(response);
                ispisi();
            }
        });
    }
}


