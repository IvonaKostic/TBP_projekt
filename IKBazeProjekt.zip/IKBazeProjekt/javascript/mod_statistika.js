$(document).ready(function () {



    function ispisi() {
        $.ajax({
            type: "get",
            url: "get_mod_statistika.php",
            data: {

            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";

                $.each(response, function (key, val) {

                    tablicaHtml +=
                            "<tr>"
                            + "<td>" + val.korime + "</td>"
                            + "<td>" + val.zbroj + "</td>"

                            + "</tr>";
                });
                $("#tableBody2").html(tablicaHtml);

            }
        });
    }
    function ispisiAnalizu() {
        $.ajax({
            type: "get",
            url: "get_mod_statistika_analiza.php",
            data: {

            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";

                $.each(response, function (key, val) {

                    tablicaHtml +=
                            "<tr>"
                            + "<td>" + val.naziv_jela + "</td>"
                            + "<td>" + val.prosjek1 + "</td>"
                            + "<td>" + val.vrijeme_pripreme + "</td>"
                            + "</tr>";
                });
                $("#tableBody3").html(tablicaHtml);

            }
        });
    }

    ispisi();
    ispisiAnalizu();



});


