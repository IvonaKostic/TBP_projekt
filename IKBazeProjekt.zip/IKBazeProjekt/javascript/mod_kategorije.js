$(document).ready(function () {



    function ispisi() {
        $.ajax({
            type: "get",
            url: "get_mod_kategorije.php",
            data: {

            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";

                $.each(response, function (key, val) {
                 
                    tablicaHtml +=
                            "<tr data-id=\"" + val.id_kategorija + "\" onclick=\""+"klik(this)"+"\">"
                            + "<td>" + val.naziv + "</td>"
                            + "<td>" + val.opis + "</td>"

                            + "</tr>";
                });
                $("#tableBody").html(tablicaHtml);

            }
        });
    }

    ispisi();

});

function klik(podaci) {
    window.location = 'mod_kat_recepti.php?id=' + $(podaci).data("id");

}


