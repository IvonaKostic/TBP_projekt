$(document).ready(function () {
    var idKat = $("#spremnik").html();


    function ispisi() {
        $.ajax({
            type: "get",
            url: "get_mod_kat_recepti.php",
            data: {
                id: idKat
            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";

                $.each(response, function (key, val) {

                    tablicaHtml +=
                            "<tr data-id=\"" + val.id_recept + "\" onclick=\"" + "klik(this)" + "\">"
                            + "<td>" + val.naziv_jela + "</td>"
                            + "<td>" + val.opis + "</td>"
                            + "<td>" + val.broj_osoba + "</td>"

                            + "</tr>";
                });
                $("#tableBody").html(tablicaHtml);

            }
        });
    }

    ispisi();

    $("#buttonDodaj").click(function () {
        console.log("IDKAT "+idKat);
        window.location = 'mod_dodaj_recept.php?id=' + idKat;
    });

});

function klik(podaci) {
    window.location = 'mod_kat_recepti_view.php?id=' + $(podaci).data("id");

}


