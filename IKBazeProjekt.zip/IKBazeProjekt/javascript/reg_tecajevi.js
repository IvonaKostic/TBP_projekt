$(document).ready(function () {


    $("#mod").click(ispisi);

    function ispisi() {
        $.ajax({
            type: "get",
            url: "get_reg_tecajevi.php",
            data: {

            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";
                var funkcija = "klik2(this)";
                let mod;
                if (document.getElementById('mod') !== null) {
                    mod = document.getElementById('mod').checked;

                    if (mod) {
                        funkcija = "klik1(this)";
                    } else {
                        funkcija = "klik2(this)";
                    }
                }
                console.log(mod);

                $.each(response, function (key, val) {
                    tablicaHtml +=
                            "<tr data-id=\"" + val.id_tecaj + "\" onclick=\"" + funkcija + "\">"
                            + "<td>" + val.naziv + "</td>"
                            + "<td>" + val.opis + "</td>"
                            + "<td>" + val.broj_mjesta + "</td>"
                            + "<td>" + val.rok_prijave + "</td>"


                            + "</tr>";
                });
                $("#tableBody").html(tablicaHtml);

            }
        });
    }

    ispisi();

    $("#buttonDodaj").click(function () {
        window.location = 'mod_dodaj_tecaj.php';
    });


});

function klik2(podaci) {
    window.location = 'reg_prijava_tecaja.php?id=' + $(podaci).data("id");

}
function klik1(podaci) {
    window.location = 'mod_azuriraj_tecaj.php?id=' + $(podaci).data("id");

}


