$(document).ready(function () {
    // Function to update the table in reg_moji_tecajevi.php
    function updateTable() {
        $.ajax({
            type: "get",
            url: "push_mod_ocjena.php",
            data: {},
            dataType: "json",
            success: function (response) {
                $(document).trigger('dataUpdated');

                var tablicaHtml = "";

                $.each(response, function (key, val) {
                    var ocjena = "Nije položen";
                    if (val.ocjena >= 2) {
                        ocjena = "Položen";
                    }

                    tablicaHtml +=
                            tablicaHtml +=
                            "<tr data-id=\"" + val.id_tecaj + "\" onclick=\"" + funkcija + "\">"
                            + "<td>" + val.naziv + "</td>"
                            + "<td>" + val.opis + "</td>"
                            + "<td>" + val.rok_prijave + "</td>"
                            + "<td>" + val.komentar + "</td>"
                            + "<td>" + ocjena + "</td>"


                            + "</tr>";
                });
                $("#tableBody").html(tablicaHtml);

            },
        });
    }

});
