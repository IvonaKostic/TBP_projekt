$(document).ready(function () {
    var trenutna_stranica = 1;
    var max_stranica = 0;
    var zapisa = 10;
    var datumKraj = null;
    var id_tecaj = null;

    function ispisi() {
        let id_tecaj = $("#spremnik").html();
        $.ajax({
            type: "get",
            url: "get_reg_tecaj_recepti.php",
            data: {
                id: id_tecaj
            },
            dataType: "json",
            success: function (response) {
                if (response.datum_kraj != null) {
                    datumKraj = response.datum_kraj;
                }
                $("#naziv").val(response.naziv_jela);
                $("#opis").val(response.opis);
                $("#postupak").val(response.postupak);
                $("#brosoba").val(response.broj_osoba);
                document.getElementById("video").src = response.video;

                id_tecaj = response.id_tecaj;

            }
        });
        $.ajax({
            type: "get",
            url: "get_sastojci.php",
            data: {
                id: id_tecaj
            },
            dataType: "json",
            success: function (response) {
                var tablicaHtml = "";

                $.each(response, function (key, val) {
                    tablicaHtml +=
                            "<tr data-id=\"" + id_tecaj + "\" onclick=\"klik(this)\">"
                            + "<td>" + val.naziv + "</td>"
                            + "<td>" + val.opis + "</td>"
                            + "<td>" + val.kolicina + " " + val.mjerna_jedinica + "</td>"



                            + "</tr>";
                });
                $("#tableBody").html(tablicaHtml);

            }
        });
    }

    function dodajHTML() {
        var html = "";
        if (usporediDatum(datumKraj)) {
            html = " <label for=\"korisnickoIme\">Potrebno vrijeme za pripremu jela (minute):</label>\
        <input type=\"text\" id=\"vrijemePotrebno\"><br><br>\
        <label for=\"korisnickoIme\">Poveznica na fotografiju jela:</label>\
        <input type=\"text\" id=\"fotka\"><br><br> <button id=\"spremi\" type=\"button\">Spremi</button> <br> <br>";
        } else {
            html = "Datum istekao";
        }
        $("#formaDodavanje").html(html);
    }

    ispisi();
    dodajHTML();

    $("#spremi").click(function () {
        console.log("KLIK");
        let vrijemePripreme = $("#vrijemePotrebno").val();
        let fotka = $("#fotka").val();
        let id_tecaj = $("#spremnik").html();
        $.ajax({
            type: "get",
            url: "push_reg_jelo.php",
            data: {
                vrijeme_pripreme: vrijemePripreme,
                fotka: fotka,
                id: id_tecaj
            },
            dataType: "json",
            success: function (response) {
                console.log("SUCCESS");
                window.location = 'reg_moji_tecajevi.php';

            }
        });
    });

    function usporediDatum(datum) {
        var q = new Date();
        var m = q.getMonth() + 1;
        var d = q.getDay();
        var y = q.getFullYear();

        var date = new Date(y, m, d);

        mydate = new Date(datum);
        console.log(date);
        console.log(mydate);

        if (date > mydate)
        {
            return true;
        } else
        {
            return false;
        }
    }
});

function klik1(podaci) {
    window.location = 'reg_tecaj_recepti.php?id=' + $(podaci).data("id");

}
function klik2(podaci) {
    window.location = 'reg_prijava_tecaja.php?id=' + $(podaci).data("id");

}

function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.documentElement.scrollHeight + 'px';
}

