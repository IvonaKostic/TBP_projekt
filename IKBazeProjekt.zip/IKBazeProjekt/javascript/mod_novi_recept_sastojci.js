$(document).ready(function () {
    $("#buttonGotovo").click(function () {
        window.location = "mod_kategorije.php";
    });

    $("#tableBodySviSastojci").on("click", "tr", function () {
        klikDodaj(this);
    });

    ispisiSve();
    ispisiDodane();
});

function ispisiSve() {
    $.ajax({
        type: "get",
        url: "get_mod_sastojci.php",
        data: {},
        dataType: "json",
        success: function (response) {
            $.each(response, function (key, val) {
                var row = $("<tr>")
                    .data("id", val.id_sastojak)
                    .append("<td>" + val.naziv + "</td>")
                    .append("<td>" + val.opis + "</td>");

                $("#tableBodySviSastojci").append(row);
            });
        }
    });
}

function ispisiDodane() {
    let idRecept = $("#spremnik").html();

    $.ajax({
        type: "get",
        url: "get_mod_recept_sastojci.php",
        data: {
            id: idRecept
        },
        dataType: "json",
        success: function (response) {
            var tablicaHtml = "";

            $.each(response, function (key, val) {
                tablicaHtml += "<tr>"
                    + "<td>" + val.naziv + "</td>"
                    + "<td>" + val.opis + "</td>"
                    + "</tr>";
            });

            $("#tableBodyDodaniSastojci").html(tablicaHtml);
        }
    });
}

function klikDodaj(data) {
    let id = $(data).data("id");
    let idRecept = $("#spremnik").html();
    let kolicina = prompt("Unesite količinu (Samo brojčano):", "5");
    let mj = prompt("Mjerna jedinica:", "KOM");

    $.ajax({
        type: "get",
        url: "push_mod_recept_sastojak.php",
        data: {
            id: id,
            idrec: idRecept,
            kol: kolicina,
            mj: mj
        },
        dataType: "json",
        success: function (response) {
            console.log(response);
            ispisiDodane();
        }
    });
}
