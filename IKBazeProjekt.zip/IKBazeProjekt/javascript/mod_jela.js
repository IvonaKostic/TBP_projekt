function ispisi() {
    $.ajax({
        type: "get",
        url: "get_mod_jela.php",
        data: {},
        dataType: "json",
        success: function (response) {
            var tablicaHtml = "";

            $.each(response, function (key, val) {
                tablicaHtml +=
                    "<tr data-kid=\"" + val.korisnik_id + "\" data-rid=\"" + val.recept_id + "\" onclick=\"" + "klik(this)" + "\">" +
                    "<td>" + val.korime + "</td>" +
                    "<td>" + val.naziv_jela + "</td>" +
                    "<td>" + val.ocjena + "</td>" +
                    "<td>" + val.komentar + "</td>" +
                    "<td><img src=\"" + val.slika + "\" alt=\"*insert picture here*\" width=\"300\" height=\"200\"></td>" +
                    "</tr>";
            });
            $("#tableBody").html(tablicaHtml);

        }
    });
}

function klik(podaci) {
    let ocjena = prompt("Unesite ocjenu (1-5):", "5");
    let komentar = prompt("Unesite komentar (100 znakova):", "Moglo je i bolje");
    if (ocjena <= 5 && ocjena >= 1) {
        $.ajax({
            type: "GET",
            url: "push_mod_ocjena.php",
            data: {
                rid: $(podaci).data("rid"),
                kid: $(podaci).data("kid"),
                ocjena: ocjena,
                komentar: komentar
            },
            dataType: "json",
            success: function (response) {
                console.log(response);
                console.log("success");
                ispisi();
                let ocjena = response.ocjena;
                let komentar = response.komentar;
                let idTecaj = response.id_tecaj;

                $("tr[data-id='" + idTecaj + "']").find("td:eq(3)").text(komentar);
                $("tr[data-id='" + idTecaj + "']").find("td:eq(4)").text(ocjena);

                // Call the function to update reg_moji_tecajevi.php table
                updateRow(idTecaj);
            }
        });
    }
}

$(document).ready(function () {
    ispisi();
});