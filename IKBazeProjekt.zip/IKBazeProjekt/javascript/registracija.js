$(document).ready(function () {
    function korime() {
        var korime = $("#korisnickoIme").val();
        $.ajax({
            type: "get",
            url: "provjeri_korime.php",
            data: {
                korime: korime,
            },
            dataType: "json",
            success: function (response) {
                if (response === "false") {
                    $("#korisnickoIme").css("border", "4px solid red");
                    $("#submitButton").attr("disabled", "true");
                } else if (response === "true") {
                    $("#korisnickoIme").css("border", "4px solid pink");
                    $("#submitButton").removeAttr("disabled");
                }
            }
        });
    }

    $("#korisnickoIme").keyup(korime);
    $("#submitButton").hover(validacijeSve);

    function validacijeSve() {
        let validacija = false;
        if (valKorime() && valIme() && valprezime() && valLozinka() && valPotvrdaLozinke() && valUvjeti()) {
            validacija = true;
        }
        if (validacija) {
            $("#submitButton").removeAttr("disabled");
            console.log("OKEEE");
        } else {
            $("#submitButton").attr("disabled", "true");
            console.log("oui");
        }
    }
    function valKorime() {
        let korime = $("#korisnickoIme").val();
        let re = /^[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*$/;
        if (re.test(korime)) {
            console.log("korime ok");
            return true;
        } else {
            return false;
        }
    }
    function valIme() {
        let val = $("#ime").val();
        let re = /^[a-z ,.'-]+$/i;
        if (re.test(val)) {
            console.log("ime ok");
            return true;
        } else {
            return false;
        }
    }
    function valprezime() {
        //prvo slovo veliko
        let val = $("#prezime").val();
        let re = /([A-Z][a-zA-Z]*)/;
        if (re.test(val)) {
            console.log("prezime ok");
            return true;
        } else {
            return false;
        }
    }

    function valLozinka() {
        //Minimum five characters, at least one letter and one number:
        let val = $("#Lozinka").val();
        let re = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{5,}$/;
        if (re.test(val)) {
            console.log("lozinka ok");
            return true;
        } else {
            return false;
        }
    }
    function valPotvrdaLozinke() {
        let val = $("#PotvrdaLoz").val();
        let val2 = $("#Lozinka").val();
        if (val === val2)
            return true;
        return false;
    }
    function valUvjeti() {

        if (document.getElementById('Terms').checked) {

            return true;
        }
        return false;
    }
    
});

