$(document).ready(function () {
    ispisi();

function ispisi(idTecaj) {
    $.ajax({
        type: "get",
        url: "get_reg_moji_tecajevi.php",
        data: {},
        dataType: "json",
        success: function (response) {
            var tablicaHtml = "";
            $.each(response, function (key, val) {
                var ocjena = "Nije položen";
                if (val.prijavljuje_ocjena >= 2) {
                    ocjena = "Položen";
                }
                var funkcija = "";
                if (usporediDatum(val.rok_prijave)) {
                    funkcija = "klik1(this)"
                } else {
                    funkcija = "klik2(this)";
                }
                tablicaHtml +=
                    "<tr data-id=\"" + val.id_tecaj + "\" onclick=\"" + funkcija + "\">" +
                    "<td>" + val.naziv + "</td>" +
                    "<td>" + val.opis + "</td>" +
                    "<td>" + val.rok_prijave + "</td>" +
                    "<td>" + val.prijavljuje_komentar  + "</td>" +
                    "<td>" + ocjena + "</td>" +
                    "</tr>";
            });
            $("#tableBody").html(tablicaHtml);

            if (idTecaj) {
                updateRow(idTecaj);
            }
        }
    });
}

function updateRow(idTecaj) {
    $.ajax({
        type: "get",
        url: "get_reg_moji_tecajevi.php",
        data: {},
        dataType: "json",
        success: function (response) {
            var updatedRow = response.find(function (val) {
                return val.id_tecaj === idTecaj;
            });
            if (updatedRow) {
                var ocjena = "Nije položen";
                if (updatedRow.prijavljuje_ocjena >= 2) {
                    ocjena = "Položen";
                }
                $("tr[data-id='" + idTecaj + "']").find("td:eq(3)").text(updatedRow.komentar);
                $("tr[data-id='" + idTecaj + "']").find("td:eq(4)").text(ocjena);
            }
        }
    });
}


    function usporediDatum(datum) {
        var q = new Date();
        var m = q.getMonth() + 1;
        var d = q.getDate(); // Fix: Use getDate() instead of getDay()
        var y = q.getFullYear();

        var date = new Date(y, m, d);

        mydate = new Date(datum);
        console.log(date);
        console.log(mydate);

        if (date > mydate) {
            return true;
        } else {
            return false;
        }
    }

});

function klik1(podaci) {
    window.location = 'reg_tecaj_recepti.php?id=' + $(podaci).data("id");
}

function klik2(podaci) {
    alert("Nije započeo tečaj još. Strpljenja molim!");
}
