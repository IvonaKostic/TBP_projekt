<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $baza = new Baza();
    $baza->spojiDB();
    if (isset($_GET["id"])) {
        $id = $_GET["id"];
        $_SESSION["id_tecaj"] = $id;
        $upit = "SELECT * FROM TECAJEVI WHERE id_tecaj = {$id}";
        $result = $baza->selectDB($upit);
        $result_aray = pg_fetch_assoc($result);

        $smarty->assign("naziv", $result_aray["naziv"]);
        $smarty->assign("opis", $result_aray["opis"]);
        $smarty->assign("brojmjesta", $result_aray["broj_mjesta"]);
        $smarty->assign("rok_prijave", $result_aray["rok_prijave"]);
        $smarty->assign("datum_zavrsetka", $result_aray["datum_kraj"]);
        $smarty->assign("recept", $result_aray["id_recept"]);
    }

    if (isset($_POST["submitDodaj"])) {
        $naziv = $_POST["Naziv"];
        $opis = $_POST["Opis"];
        $brojmjesta = $_POST["BrojMjesta"];
        $rokprijave = $_POST["RokPrijave"];
        $datumzavrsetka = $_POST["Kraj"];
        $recept = $_POST["recept"];

        $upit = "UPDATE TECAJEVI SET broj_mjesta= {$brojmjesta},rok_prijave= '{$rokprijave}',datum_kraj= '{$datumzavrsetka}',opis= '{$opis}',naziv= '{$naziv}',id_recept= {$recept} WHERE id_tecaj = {$_SESSION["id_tecaj"]}";
        $result = $baza->updateDB($upit);
        ob_start();
        //fb("INSERT " . $result);
        header("Location: reg_tecajevi.php");
    }
    $smarty->display("mod_azuriraj_tecaj.tpl");
    require 'podnozje.php';
    $baza->zatvoriDB();
}