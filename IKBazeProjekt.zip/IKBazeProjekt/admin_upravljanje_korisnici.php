<?php
require 'zaglavlje.php';

if(isset($_SESSION["uloga"]) && $_SESSION["uloga"]==4){
    $smarty->display("admin_upravljanje_korisnici.tpl");
}
require 'podnozje.php';