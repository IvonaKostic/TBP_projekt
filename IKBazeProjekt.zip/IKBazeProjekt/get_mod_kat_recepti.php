<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $sadrzaj = array();
    $korime = $_SESSION["korisnik"];
    if (isset($_GET["id"])) {
        $baza = new Baza();
        $baza->spojiDB();
        $id_kat = $_GET["id"];

        $upit = "SELECT * FROM RECEPTI r WHERE r.\"KATEGORIJE_id_kategorija\" = {$id_kat}";
        $rezultat = $baza->selectDB($upit);
        $baza->zatvoriDB();

        while ($row = pg_fetch_assoc($rezultat)) {
            $sadrzaj[] = $row;
        }
        echo json_encode($sadrzaj);
    }
}