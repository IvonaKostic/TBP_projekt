<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    //$podaci = array();

    $baza = new Baza();
    $baza->spojiDB();
    require './korisnik_id.php';
    $id_tecaj = $_GET["id"];
    $vrijeme = $_GET["vrijeme_pripreme"];
    $fotka = $_GET["fotka"];

    $upit = "SELECT t.id_recept FROM TECAJEVI t WHERE t.id_tecaj = {$id_tecaj}";
    $rezultat = $baza->selectDB($upit);

    $result_array = pg_fetch_assoc($rezultat);
    $id_recept = $result_array["id_recept"];
    $upit = 'INSERT INTO SLIJEDI_RECEPT("korisnik_id", "recept_id", "slika", "vrijeme_minute")' . " VALUES ({$korisnik_id},{$id_recept},'{$fotka}',{$vrijeme})";
    $baza->updateDB($upit);
    //    foreach ($rezultat as $kljuc => $vrijednost) {
//        $podaci[] = $vrijednost;
//    }
//    echo json_encode($podaci);
    echo json_encode("gotovo");
    $baza->zatvoriDB();
}