<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    //$podaci = array();

    $baza = new Baza();
    $baza->spojiDB();
    $id_sastojak = $_GET["id"];
    $id_recept = $_GET["idrec"];
    $kolicina = $_GET["kol"];
    $mjerna_jedinica = $_GET["mj"];

    $upit = 'INSERT INTO SADRZI_SASTOJAK("kolicina", "mjerna_jedinica", "SASTOJCI_id_sastojak", "RECEPTI_id_recept") '
            . "VALUES ({$kolicina},'{$mjerna_jedinica}',{$id_sastojak},{$id_recept})";
    $baza->updateDB($upit);
//    foreach ($rezultat as $kljuc => $vrijednost) {
//        $podaci[] = $vrijednost;
//    }
//    echo json_encode($podaci);
    echo json_encode("gotovo");
    $baza->zatvoriDB();
}
