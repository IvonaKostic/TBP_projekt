<?php

require 'korijen.php';
Sesija::obrisiSesiju();
if(isset($_SESSION["uloga"])){
    header("Location: index.php");
}
else{
    header("Location: prijava.php");
}
