<?php

error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);

class Baza {

    const server = "localhost";
    const korisnik = "postgres";
    const lozinka = "postgres";
    const baza = "postgres1";

    private $veza = null;
    private $greska = '';

    function spojiDB() {
        ob_start();
        fb("prije spajanja");
        $this->veza = pg_connect("host=localhost port=5433 dbname=postgres1 user=postgres password=postgres");
        fb("poslije spajanja");
        if (!$this->veza) {
            ob_start();
            fb("Neuspješno spajanje na bazu: " . pg_last_error() . " ... ");
            echo "Neuspješno spajanje na bazu: " . pg_last_error();
            $this->greska = pg_last_error();
        }
        //fb("veza: ".$this->veza);
        return $this->veza;
    }

    function zatvoriDB() {
        pg_close($this->veza);
    }

    function selectDB($upit) {
        $rezultat = pg_query($this->veza, $upit);
        if (!$rezultat) {
            echo "Greška kod upita: {$upit} - " . pg_last_error($this->veza);
            $this->greska = pg_last_error($this->veza);
        }
        if (!$rezultat) {
            $rezultat = null;
        }
        return $rezultat;
    }

    function selectAltDB($upit) {
        $rezultat = pg_query($this->veza, $upit);
        if (!$rezultat) {
            die('Invalid query: ' . pg_last_error($this->veza));
        } else {
            return pg_last_oid($rezultat);
        }
    }

    function updateDB($upit, $skripta = '') {
        $rezultat = pg_query($this->veza, $upit);
        if (!$rezultat) {
            echo "Greška kod upita: {$upit} - " . pg_last_error($this->veza);
            $this->greska = pg_last_error($this->veza);
        } else {
            if ($skripta != '') {
                header("Location: $skripta");
            }
        }

        // Check if $rezultat is a valid result object
        if ($rezultat && is_object($rezultat)) {
            return pg_last_oid($rezultat);
        } else {
            return null; // or handle the case when $rezultat is not a valid result object
        }
    }

    function pogreskaDB() {
        if ($this->greska != '') {
            return true;
        } else {
            return false;
        }
    }

}

?>