<?php

require 'korijen.php';

if (isset($_GET["email"])) {
    $baza = new Baza();
    $baza->spojiDB();
    $email = $_GET["email"];
    $upit = "SELECT * FROM KORISNICI WHERE email = '{$email}'";
    $result = $baza->selectDB($upit);
    $result_aray = pg_fetch_assoc($result);
    if ($result_aray["email"] == $email) {
        echo json_encode("false");
    } else {
        echo json_encode("true");
    }
}

