<?php
require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $baza = new Baza();
    $baza->spojiDB();
    $id_recept = $_POST["id"];

    // Delete related records from the 'SADRZI_SASTOJAK' table
    $upit = "DELETE FROM SADRZI_SASTOJAK WHERE RECEPTI_id_recept = '{$id_recept}'";
    $baza->updateDB($upit);

    // Delete the recipe from the 'RECEPTI' table
    $upit = "DELETE FROM RECEPTI WHERE id_recept = '{$id_recept}'";
    $baza->updateDB($upit);

    echo json_encode("gotovo");
    $baza->zatvoriDB();
}
?>
