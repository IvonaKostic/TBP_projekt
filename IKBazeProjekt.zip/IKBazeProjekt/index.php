<?php

require 'zaglavlje.php';

$smarty->display("index.tpl");
//$smarty->display("podnozje.tpl");

require 'podnozje.php';
