<?php
$toEmail = 'lanamill62@gmail.com'; // Replace with the recipient's email address
$subject = 'Test Email';
$content = 'This is a test email.';

$mailHeaders = "From: sender@example.com\r\n";
$mailHeaders .= "Reply-To: sender@example.com\r\n";

if (mail($toEmail, $subject, $content, $mailHeaders)) {
    echo 'Email sent successfully.';
} else {
    echo 'Error sending email.';
}
?>
