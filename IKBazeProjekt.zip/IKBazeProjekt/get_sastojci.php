<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $podaci = array();

    $veza = new Baza();
    $veza->spojiDB();
    $id_tecaj = $_GET["id"];

    $upit = "SELECT s.id_sastojak, s.naziv, s.opis, s.rok_trajanja, ss.kolicina, ss.mjerna_jedinica FROM TECAJEVI t, SADRZI_SASTOJAK ss, SASTOJCI s WHERE t.id_tecaj = {$id_tecaj} AND t.id_recept = ss.\"RECEPTI_id_recept\" AND ss.\"SASTOJCI_id_sastojak\" = s.id_sastojak";
    $rezultat = $veza->selectDB($upit);
    $veza->zatvoriDB();

    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    echo json_encode($podaci);
}