<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $sadrzaj = array();
    $korime = $_SESSION["korisnik"];

    $baza = new Baza();
    $baza->spojiDB();
    require 'korisnik_id.php';

    $upit = "SELECT * FROM kategorije k, korisnici ko, moderira m WHERE k.id_kategorija = m.id_kategorija AND ko.id_korisnik = m.id_korisnik AND ko.id_korisnik = {$korisnik_id}";
    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();


    while ($row = pg_fetch_assoc($rezultat)) {
        $sadrzaj[] = $row;
    }

    echo json_encode($sadrzaj);
}