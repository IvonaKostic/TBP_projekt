<?php
require 'zaglavlje.php';

if(isset($_SESSION["uloga"]) && $_SESSION["uloga"]>=2){
   
    if(isset($_GET["id"])){
        $id = $_GET["id"];
        $smarty->assign("spremnik",$id);
    }
     $smarty->display("reg_tecaj_recepti.tpl");
}
require 'podnozje.php';