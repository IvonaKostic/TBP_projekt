<?php

$korisnik = $_SESSION["korisnik"];
$uloga = $_SESSION["uloga"];

$upit = "SELECT * FROM KORISNICI WHERE korime ='{$korisnik}'";

$result = $baza->selectDB($upit);
$result_array = pg_fetch_assoc($result);
$korisnik_id = $result_array["id_korisnik"];

