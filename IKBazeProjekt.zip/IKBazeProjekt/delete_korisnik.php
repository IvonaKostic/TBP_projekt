<?php
require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $baza = new Baza();
    $baza->spojiDB();
    $id_korisnik = $_GET["id_korisnik"];

    $upit = "SELECT id_korisnik, \"ULOGE_id_uloga\" FROM korisnici WHERE id_korisnik = '{$id_korisnik}'";
    $rezultat = $baza->selectDB($upit);
    $red = pg_fetch_assoc($rezultat);

    if ($red["ULOGE_id_uloga"] == 4) {
        echo json_encode("Nije moguće izbrisati administratorski račun.");
    } else {

        $upit = "DELETE FROM prijavljuje WHERE \"TECAJEVI_id_tecaj\" IN (SELECT id_tecaj FROM tecajevi WHERE id_recept IN (SELECT id_recept FROM recepti WHERE id_mod = '{$id_korisnik}'))";
        $baza->updateDB($upit);

  
        $upit = "DELETE FROM tecajevi WHERE id_recept IN (SELECT id_recept FROM recepti WHERE id_mod = '{$id_korisnik}')";
        $baza->updateDB($upit);

        $upit = "DELETE FROM recepti WHERE id_mod = '{$id_korisnik}'";
        $baza->updateDB($upit);

        $upit = "DELETE FROM korisnici WHERE id_korisnik = '{$id_korisnik}'";
        $baza->updateDB($upit);

        echo json_encode("gotovo");
    }

    $baza->zatvoriDB();
}
?>