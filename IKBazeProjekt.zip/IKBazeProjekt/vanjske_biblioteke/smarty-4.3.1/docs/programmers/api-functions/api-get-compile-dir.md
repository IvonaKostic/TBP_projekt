getCompileDir()

returns the directory where compiled templates are stored

Description
===========

string

getCompileDir


    <?php

    // get directory where compiled templates are stored
    $compileDir = $smarty->getCompileDir();

    ?>

       

See also [`setCompileDir()`](#api.set.compile.dir) and
[`$compile_dir`](#variable.compile.dir).
