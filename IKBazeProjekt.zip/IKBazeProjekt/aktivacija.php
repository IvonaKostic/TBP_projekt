<?php
require 'zaglavlje.php';

if(isset($_GET["kod"])){
    $kod = $_GET["kod"];
    $registracija = new Registracija();
    $baza = new Baza();
    $baza->spojiDB();
    $aktiviran = $registracija->aktiviraj($kod, $baza);
    $baza->zatvoriDB();
    if($aktiviran){
        $smarty->assign("poruka","Korisnik je aktiviran");
    }
    else{
        $smarty->assign("poruka","Korisnik nije aktiviran");
    }
}
//$smarty->assign("poruka","Korisnik je aktiviran");
$smarty->display("aktivacija.tpl");
require 'podnozje.php';

