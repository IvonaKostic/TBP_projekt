<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $baza = new Baza();
    $baza->spojiDB();
    if (isset($_GET["id"])) {
        $id_tecaj = $_GET["id"];
        $_SESSION["id_tecaj"] = $id_tecaj;

        require 'korisnik_id.php';

        $upit = 'SELECT * FROM TECAJEVI t, PRIJAVLJUJE p WHERE p."KORISNICI_id_korisnik" = ' . $korisnik_id . ' AND p."TECAJEVI_id_tecaj" = t.id_tecaj AND t.id_tecaj = ' . $id_tecaj;
        $result = $baza->selectDB($upit);
        fb($upit);

        $result_array = pg_fetch_assoc($result);
        $upit = "SELECT * FROM TECAJEVI WHERE id_tecaj = {$id_tecaj}";
        $result = $baza->selectDB($upit);
        $result_array2 = pg_fetch_assoc($result);
        $smarty->assign("naziv", $result_array2["naziv"]);
        $smarty->assign("opis", $result_array2["opis"]);
        $smarty->assign("datum", $result_array2["rok_prijave"]);
        $smarty->assign("broj_mjesta", $result_array2["broj_mjesta"]);

        if (isset($result_array["datum_prijave"])) {

            //            $dtime_rokPrijave = DateTime::createFromFormat($date_format, $result_array["rok_prijave"]);
//            $timestamp_rok = $dtime_rokPrijave->getTimestamp();
            $timestamp_rok = strtotime($result_array2["rok_prijave"]);
            fb("ROK " . $result_array2["rok_prijave"]);
            $timestamp_now = time();
            fb("now " . $timestamp_now . " " . $timestamp_rok);
            if ($timestamp_now < $timestamp_rok) {
                fb("TU SAM OVDJE TU");
                $smarty->assign("odjava", true);
            }
        } else {
            $timestamp_rok = strtotime($result_array2["rok_prijave"]);
            fb("ROK " . $result_array2["rok_prijave"]);
            $timestamp_now = time();
            fb("now " . $timestamp_now . " " . $timestamp_rok);
            if ($timestamp_now < $timestamp_rok) {
                fb("TU SAM OVDJE TU");
                $smarty->assign("prijava", true);
            }
        }

        $smarty->display("reg_prijava_tecaja.tpl");
    }

    if (isset($_POST["submitOdjava"])) {
        require_once './korisnik_id.php';
        $upit = 'DELETE FROM PRIJAVLJUJE WHERE "KORISNICI_id_korisnik" = ' . $korisnik_id . ' AND "TECAJEVI_id_tecaj" = ' . $_SESSION["id_tecaj"];

        $baza->updateDB($upit);
        fb($upit);
        header("Location: reg_tecajevi.php");
    }

    if (isset($_POST["submit"])) {
        require_once './korisnik_id.php';
        $upit = 'INSERT INTO PRIJAVLJUJE("datum_prijave", "KORISNICI_id_korisnik", "TECAJEVI_id_tecaj")'
            . " VALUES ('{$date_now}',{$korisnik_id},{$_SESSION["id_tecaj"]})";
        $baza->updateDB($upit);
        fb($upit);
        header("Location: reg_tecajevi.php");
    }

    $baza->zatvoriDB();
}
require 'podnozje.php';