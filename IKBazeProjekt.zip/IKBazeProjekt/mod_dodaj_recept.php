<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $baza = new Baza();
    $baza->spojiDB();
    if (isset($_GET["id"])) {
        $id_kat = $_GET["id"];
        $_SESSION["id_kat"] = $id_kat;
        fb("KAT ".$_SESSION["id_kat"]);

        $baza->zatvoriDB();
    }
    if (isset($_POST["submitDodaj"])) {
        $naziv = $_POST["Naziv"];
        $opis = $_POST["Opis"];
        $broj_osoba = $_POST["BrojOsoba"];
        $postupak = $_POST["Postupak"];
        $video = $_POST["Video"];
        $vrijeme = $_POST["Vrijeme"];
        require 'korisnik_id.php';
        
        $upit = 'INSERT INTO RECEPTI( "naziv_jela", "opis", "broj_osoba", "postupak", "KATEGORIJE_id_kategorija", "video","id_mod","vrijeme_pripreme") '
                . "VALUES ('{$naziv}','{$opis}',{$broj_osoba},'{$postupak}',{$_SESSION["id_kat"]},'{$video}',{$korisnik_id},{$vrijeme})";
        $result = $baza->updateDB($upit);
        ob_start();
        fb("INSERT ".$result);
        header("Location: mod_novi_recept_sastojci.php?id=".$result);
    }
    $smarty->display("mod_dodaj_recept.tpl");
    require 'podnozje.php';
} 