<?php

require 'korijen.php';

if (isset($_GET["korime"])) {
    $baza = new Baza();
    $baza->spojiDB();
    $korime = $_GET["korime"];
    $upit = "SELECT * FROM KORISNICI WHERE korime = '{$korime}'";
    $result = $baza->selectDB($upit);
    $result_aray = pg_fetch_assoc($result);
    if ($result_aray["korime"] == $korime) {
        echo json_encode("false");
    } else {
        echo json_encode("true");
    }
}

