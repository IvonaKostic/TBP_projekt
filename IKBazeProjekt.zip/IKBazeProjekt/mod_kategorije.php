<?php
require 'zaglavlje.php';

if(isset($_SESSION["uloga"]) && $_SESSION["uloga"]>=3){
    $smarty->display("mod_kategorije.tpl");
}
require 'podnozje.php';