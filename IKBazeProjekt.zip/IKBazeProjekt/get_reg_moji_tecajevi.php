<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $redak = array();
    $korime = $_SESSION["korisnik"];

    $veza = new Baza();
    $veza->spojiDB();

    $upit = "SELECT t.*, p.ocjena AS prijavljuje_ocjena, p.komentar AS prijavljuje_komentar, sr.ocjena AS slijedi_ocjena, r.ocjena_recept
             FROM TECAJEVI t
             JOIN PRIJAVLJUJE p ON t.id_tecaj = p.\"TECAJEVI_id_tecaj\"
             JOIN KORISNICI k ON p.\"KORISNICI_id_korisnik\" = k.id_korisnik
             LEFT JOIN SLIJEDI_RECEPT sr ON sr.recept_id = t.id_tecaj AND sr.korisnik_id = k.id_korisnik
             LEFT JOIN RECEPTI r ON r.id_recept = sr.recept_id
             WHERE k.korime = '{$korime}'";
    $rezultat = $veza->selectDB($upit);

    while ($redak = pg_fetch_assoc($rezultat)) {
        if (!empty($redak['slijedi_ocjena']) && !empty($redak['slijedi_komentar'])) {
            $redak['prijavljuje_ocjena'] = $redak['slijedi_ocjena'];
            $redak['prijavljuje_komentar'] = $redak['slijedi_komentar'];
            
            $updateQuery = "UPDATE prijavljuje SET ocjena = '{$row['prijavljuje_ocjena']}', komentar = '{$row['prijavljuje_komentar']}' WHERE \"TECAJEVI_id_tecaj\" = '{$row['id_tecaj']}'";
            $veza->izvrsiDB($updateQuery);
        }
        $sadrzaj[] = $redak;
    }
    
    

    $veza->zatvoriDB();

    echo json_encode($sadrzaj);
}
