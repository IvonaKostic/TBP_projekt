<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $sadrzaj = array();
    $korime = $_SESSION["korisnik"];

    $baza = new Baza();
    $baza->spojiDB();

    $upit = "SELECT * FROM RECEPTI";
    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

    while ($row = pg_fetch_assoc($rezultat)) {
        $sadrzaj[] = $row;
    }
    echo json_encode($sadrzaj);
}