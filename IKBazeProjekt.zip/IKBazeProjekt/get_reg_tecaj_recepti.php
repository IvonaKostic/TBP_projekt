<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $podaci = array();

    $veza = new Baza();
    $veza->spojiDB();
    $id_tecaj = $_GET["id"];

    $upit = "SELECT * FROM TECAJEVI t, RECEPTI r WHERE t.id_tecaj = {$id_tecaj} AND t.id_recept = r.id_recept;";
    $rezultat = $veza->selectDB($upit);
    $veza->zatvoriDB();
    
    $result_array = pg_fetch_assoc($rezultat);

    //    foreach ($rezultat as $kljuc => $vrijednost) {
//        $sadrzaj[] = $vrijednost;
//    }
    echo json_encode($result_array);
}