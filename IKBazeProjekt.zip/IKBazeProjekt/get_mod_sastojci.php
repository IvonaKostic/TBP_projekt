<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $podaci = array();

    $veza = new Baza();
    $veza->spojiDB();

    $upit = "SELECT * FROM SASTOJCI";
    $rezultat = $veza->selectDB($upit);
    $veza->zatvoriDB();

    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    echo json_encode($podaci);
}