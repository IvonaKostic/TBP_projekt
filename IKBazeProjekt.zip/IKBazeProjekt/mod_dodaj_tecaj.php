<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 2) {
    $baza = new Baza();
    $baza->spojiDB();

    if (isset($_POST["submitDodaj"])) {
        $naziv = $_POST["Naziv"];
        $opis = $_POST["Opis"];
        $brojmjesta = $_POST["BrojMjesta"];
        $rokprijave = $_POST["RokPrijave"];
        $datumzavrsetka = $_POST["Kraj"];
        $recept = $_POST["recept"];
        require 'korisnik_id.php';
        $upit = 'INSERT INTO TECAJEVI("broj_mjesta", "rok_prijave", "datum_kraj", "opis", "naziv", "id_recept","id_mod") '
            . "VALUES ({$brojmjesta},'{$rokprijave}', '{$datumzavrsetka}', '{$opis}', '{$naziv}', {$recept},{$korisnik_id})";
        $result = $baza->updateDB($upit);
        ob_start();
        fb("INSERT " . $result);
        header("Location: reg_tecajevi.php");
    }
    $smarty->display("mod_dodaj_tecaj.tpl");
    require 'podnozje.php';
    $baza->zatvoriDB();
}