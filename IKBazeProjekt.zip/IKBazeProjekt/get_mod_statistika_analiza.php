<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $podaci = array();

    $baza = new Baza();
    $baza->spojiDB();
    require 'korisnik_id.php';
    $upit = "SELECT r.naziv_jela, (SELECT AVG(SLIJEDI_RECEPT.vrijeme_minute) FROM SLIJEDI_RECEPT WHERE SLIJEDI_RECEPT.recept_id = r.id_recept ) as prosjek1, r.vrijeme_pripreme FROM RECEPTI r WHERE r.id_mod = {$korisnik_id}";
    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    echo json_encode($podaci);
}