<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $podaci = array();

    $baza = new Baza();
    $baza->spojiDB();
    require 'korisnik_id.php';
    $upit = "SELECT k.korime, (SELECT COUNT(t.id_tecaj) FROM TECAJEVI t,PRIJAVLJUJE p, SLIJEDI_RECEPT sr WHERE sr.korisnik_id = k.id_korisnik AND t.id_recept = sr.recept_id AND p.\"KORISNICI_id_korisnik\" = k.id_korisnik AND p.\"TECAJEVI_id_tecaj\" = t.id_tecaj AND sr.ocjena > 1 AND t.id_mod = {$korisnik_id}) as zbroj FROM KORISNICI k";
    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    echo json_encode($podaci);
}