<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    if (isset($_GET["id"])) {
        $smarty->assign("spremnik", $_GET["id"]);
        $smarty->display("mod_novi_recept_sastojci.tpl");
    }
}
require 'podnozje.php';
