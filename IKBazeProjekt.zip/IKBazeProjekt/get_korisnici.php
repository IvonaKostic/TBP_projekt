<?php

require 'korijen.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] == 4) {
    $podaci = array();

    $veza = new Baza();
    $veza->spojiDB();
    $id_tecaj = $_GET["id"];

    $upit = "SELECT k.id_korisnik, k.ime, k.prezime, k.korime, k.email, k.broj_pokusaja, k.omogucen, k.datum_registracije, u.naziv FROM KORISNICI k, ULOGE u WHERE k.\"ULOGE_id_uloga\" = u.id_uloga";
    $rezultat = $veza->selectDB($upit);
    //$rezultat = pg_fetch_all($rezultat);


    while ($row = pg_fetch_assoc($rezultat)) {
        $podaci[] = $row;
    }
    $veza->zatvoriDB();
    echo json_encode($podaci);
}