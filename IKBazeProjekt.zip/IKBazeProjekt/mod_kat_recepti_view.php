<?php

require 'zaglavlje.php';

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] >= 3) {
    $baza = new Baza();
    $baza->spojiDB();
    if (isset($_GET["id"])) {
        $smarty->assign("spremnik", $_GET["id"]);
        $_SESSION["id_recept"] = $_GET["id"];
        $baza = new Baza();
        $baza->spojiDB();
        $upit = "SELECT * FROM RECEPTI WHERE id_recept = {$_GET["id"]}";
        $result = $baza->selectDB($upit);
        $result_array = pg_fetch_assoc($result);

        $smarty->assign("naziv", $result_array["naziv_jela"]);
        $smarty->assign("opis", $result_array["opis"]);
        $smarty->assign("brosoba", $result_array["broj_osoba"]);
        $smarty->assign("postupak", $result_array["postupak"]);
        $smarty->assign("video", $result_array["video"]);
        $smarty->display("mod_kat_recepti_view.tpl");
    }
    if (isset($_POST["submitDodaj"])) {
        $id_recept = $_SESSION["id_recept"];
        $naziv = $_POST["Naziv"];
        $opis = $_POST["Opis"];
        $brosoba = $_POST["BrojOsoba"];
        $postupak = $_POST["Postupak"];
        $video = $_POST["Video"];

        $upit = "UPDATE RECEPTI SET naziv_jela='{$naziv}',opis='{$opis}',broj_osoba={$brosoba},postupak='{$postupak}',video='{$video}' WHERE id_recept = {$id_recept}";
        $baza->updateDB($upit);
        header("Location: mod_kategorije.php");
    }

    if (isset($_POST["buttonBrisi"])) {
        $id_recept = $_SESSION["id_recept"];
        $naziv = $_POST["Naziv"];
        $opis = $_POST["Opis"];
        $brosoba = $_POST["BrojOsoba"];
        $postupak = $_POST["Postupak"];
        $video = $_POST["Video"];
        // Delete the recipe from the database
        $upit = "DELETE FROM RECEPTI WHERE id_recept = {$id_recept}";
        $baza->updateDB($upit);

        // Redirect to the desired page after deletion
        header("Location: mod_kategorije.php");
        exit(); // Make sure to exit after redirecting
    }

    $baza->zatvoriDB();
}
require 'podnozje.php';
