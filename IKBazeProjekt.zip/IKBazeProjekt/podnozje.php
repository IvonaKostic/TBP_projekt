<?php

$smarty->display("podnozje.tpl");

