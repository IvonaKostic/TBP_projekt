<?php

require 'zaglavlje.php';
if(isset($_GET["poruka"])){
    $smarty->assign("poruka",$_GET["poruka"]);
    $smarty->display("poruka.tpl");
}
require 'podnozje.php';
